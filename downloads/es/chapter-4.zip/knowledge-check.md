Responda antes de ejecutar la práctica de cambio/ARP.

1. Un conmutador nuevo de tres puertos recibe `A → B` en p1. ¿Qué aprende y dónde transmite la trama?
2. Posteriormente recibe `B → A` en p2. Prediga la decisión reenvío y la tabla aprendida completa.
3. ¿Qué sucede si el switch ha aprendido el destino A en el mismo puerto de entrada al que llega una trama para A?
4. Explique la diferencia entre transmisión una Ethernet y una unidifusión desconocida.
5. ¿Por qué una solicitud ARP suele utilizar la transmisión Ethernet?
6. Su destino IP es remoto y su ruta utiliza la puerta de enlace `192.0.2.1`. ¿Qué dirección IP resuelve su host en MAC antes de enviar la primera trama?
7. ¿Quién es el propietario de la caché ARP y quién es el propietario de la tabla de aprendizaje de puertos MAC→?
8. Un host se mueve del puerto del conmutador p1 al p3. ¿Qué propiedad de la trama observada permite que el conmutador vuelva a aprender su ubicación?
9. ¿Por qué una ruta IP válida aún no puede entregar tráfico cuando falla la resolución del vecino?

Después de responder, utilice `make list-tests` para asignar cada predicción a los casos públicos.
