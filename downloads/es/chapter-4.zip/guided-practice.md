# Práctica guiada — Aprender la tabla del switch antes de usar ARP

**Tiempo:** 10–12 minutos  
**Materiales:** papel o un editor de texto; no requiere acceso a Internet

## Predicción

Un switch de aprendizaje tiene tres puertos. El host A está en el puerto 1, B en el puerto 2 y C en el puerto 3. La tabla del switch comienza vacía.

Prediga qué hace el switch con la primera trama `A → C`: ¿la descarta, la inunda o la envía por un único puerto conocido? Escriba también qué dirección aprende a partir de esa trama.

## Ejemplo resuelto

Un switch de aprendizaje aprende a partir de la dirección MAC **origen** de cada trama recibida. Usa la dirección MAC **destino** para decidir por dónde enviarla.

Para la primera trama `A → C`:

```text
recibe por puerto 1
aprende A → puerto 1
el destino C es desconocido
inunda por puertos 2 y 3
```

Si C responde `C → A`, el switch aprende `C → puerto 3` y puede enviar esa respuesta únicamente por el puerto 1.

## Microexperimento guiado

Comenzando con una tabla vacía, procese manualmente esta secuencia:

```text
1. A → C llega por puerto 1
2. C → A llega por puerto 3
3. B → C llega por puerto 2
4. A → B llega por puerto 1
```

Después de cada trama, anote:

- la tabla aprendida;
- si la trama se inunda o se reenvía por un único puerto;
- el puerto o los puertos de salida.

Mantenga ahora la misma topología y considere esta solicitud ARP de A:

```text
destino Ethernet: ff:ff:ff:ff:ff:ff
pregunta ARP: ¿Quién tiene 10.0.0.1? Responda a 10.0.0.10.
```

Responda:

1. ¿Por qué el switch inunda esta trama aunque su tabla de aprendizaje ya contenga la MAC de la puerta de enlace?
2. ¿Qué aprende A de una respuesta ARP que el propio switch **no** aprende?
3. ¿Qué tabla relaciona direcciones MAC con puertos del switch y qué caché relaciona próximos saltos IP con direcciones de enlace?

## Evidencia que debe conservar

Conserve la traza de cuatro pasos de la tabla del switch y una comparación de dos columnas tituladas `aprendizaje del switch` y `resolución ARP/vecinos`. Debe poder explicar por qué ambos mecanismos cooperan sin resolver el mismo problema.
