Una LAN conmutada tiene dos tipos de estado que debe mantener separados: un conmutador aprende asignaciones de **MAC → puerto**, mientras que los hosts aprenden asignaciones de **IP → MAC** mediante ARP (o mecanismos equivalentes de descubrimiento de vecinos en IPv6).

## Predecir

Antes de realizar las pruebas, responda:

1. ¿Qué hace un switch nuevo con un destino de unidifusión desconocido?
2. ¿Qué dirección aprende el conmutador: origen, destino o ambos?
3. ¿Qué sucede cuando se aprende un destino conocido en el mismo puerto al que llega una trama?
4. ¿Por qué normalmente se envía una solicitud ARP al destino de transmisión Ethernet?
5. ¿Qué máquina posee un caché ARP: switch o host?

## Construir

Implementar `src/lan.py`:

- fuente-MAC aprendizaje,
- reenvío de unidifusión conocida,
- inundaciones de difusión y unidifusión desconocidas,
- filtrado en el mismo puerto,
- un caché mínimo de host ARP.

La topología canónica de este laboratorio es `switched-lan`. Después de extraer el ZIP del laboratorio, inspeccione su archivo con:

```bash
python3 -m json.tool fixtures/switched-lan.json
```

Una asignación exportada recibe el mismo activo que `fixtures/switched-lan.json`.

## Prueba

Todos los casos son visibles:

```bash
make list-tests
make test
make test-case CASE=broadcast
```

Agregue casos adicionales en `tests/student/`.

## observar

En una interfaz real/local, inspeccione el vecino actual y estado de enlace:

```bash
ip link
ip neigh
```

Si captura de paquetes está disponible, borre o elija una interacción de vecino sin caché y observe una solicitud/respuesta de ARP. Identifique las direcciones de origen/destino de Ethernet por separado de las direcciones de protocolo del emisor/destino dentro de ARP.

## Explicar

Describe una secuencia en la que la tabla de conmutadores cambia pero la caché del host ARP no, y otra en la que el estado de ARP cambia sin cambiar la topología del conmutador físico. Conecte el modelo determinista con la evidencia del paquete.

GitHub Actions sigue siendo opcional y repite únicamente el mismo conjunto público local.
