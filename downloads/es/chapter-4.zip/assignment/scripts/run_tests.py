#!/usr/bin/env python3
"""Standalone transparent assignment test runner.

This file is copied into every exported assignment so local testing does not
depend on the course repository, GitHub, pytest, or cnlab being installed.
"""

import argparse
import importlib.util
import sys
import unittest
from pathlib import Path


def load_module(path):
    name = "assignment_test_%s_%s" % (path.stem, abs(hash(str(path.resolve()))))
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load %s" % path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def cases(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from cases(item)
        else:
            yield item


def main():
    parser = argparse.ArgumentParser(description="Run all public assignment tests")
    parser.add_argument("--case", help="only run test IDs containing this substring")
    parser.add_argument("--list", action="store_true", help="list matching public tests without running them")
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    for entry in (root, root / "src"):
        if str(entry) not in sys.path:
            sys.path.insert(0, str(entry))

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    for test_root in (root / "tests" / "official", root / "tests" / "student"):
        if not test_root.exists():
            continue
        for path in sorted(test_root.rglob("test*.py")):
            loaded = loader.loadTestsFromModule(load_module(path))
            for test in cases(loaded):
                if args.case and args.case.lower() not in test.id().lower():
                    continue
                suite.addTest(test)

    count = suite.countTestCases()
    if not count:
        print("No tests found%s." % (" for case %r" % args.case if args.case else ""))
        return 2

    if args.list:
        for test in cases(suite):
            print(test.id())
        print("\n%d transparent local test(s)." % count)
        return 0

    print("Running %d transparent local test(s)." % count)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
