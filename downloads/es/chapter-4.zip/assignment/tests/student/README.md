Add your own switch-learning and ARP-cache cases here. Try host moves, broadcasts, repeated resolution, and unusual port orderings.
