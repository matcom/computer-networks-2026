import unittest

from src.lan import BROADCAST, Frame, LearningSwitch, learn_arp, resolve_arp, should_answer_arp


class LearningSwitchTests(unittest.TestCase):
    def setUp(self):
        self.switch = LearningSwitch(["p1", "p2", "p3"])

    def test_unknown_unicast_floods_except_ingress(self):
        out = self.switch.receive(Frame("00:00:00:00:00:01", "00:00:00:00:00:02"), "p1")
        self.assertEqual(out, ("p2", "p3"))

    def test_source_is_learned_on_ingress(self):
        self.switch.receive(Frame("00:00:00:00:00:01", "00:00:00:00:00:02"), "p1")
        self.assertEqual(self.switch.table["00:00:00:00:00:01"], "p1")

    def test_known_unicast_uses_single_port(self):
        self.switch.receive(Frame("00:00:00:00:00:02", "00:00:00:00:00:01"), "p2")
        out = self.switch.receive(Frame("00:00:00:00:00:01", "00:00:00:00:00:02"), "p1")
        self.assertEqual(out, ("p2",))

    def test_destination_on_same_ingress_is_filtered(self):
        self.switch.table["00:00:00:00:00:02"] = "p1"
        out = self.switch.receive(Frame("00:00:00:00:00:01", "00:00:00:00:00:02"), "p1")
        self.assertEqual(out, ())

    def test_broadcast_always_floods_except_ingress(self):
        out = self.switch.receive(Frame("00:00:00:00:00:01", BROADCAST), "p2")
        self.assertEqual(out, ("p1", "p3"))

    def test_host_move_updates_learning_table(self):
        src = "00:00:00:00:00:01"
        self.switch.receive(Frame(src, BROADCAST), "p1")
        self.switch.receive(Frame(src, BROADCAST), "p3")
        self.assertEqual(self.switch.table[src], "p3")

    def test_unknown_ingress_port_is_rejected(self):
        with self.assertRaises(ValueError):
            self.switch.receive(Frame("00:00:00:00:00:01", BROADCAST), "p9")


class ArpCacheTests(unittest.TestCase):
    def test_missing_binding_requires_resolution(self):
        self.assertIsNone(resolve_arp({}, "192.0.2.20"))

    def test_learning_binding_makes_it_resolvable(self):
        cache = {}
        learn_arp(cache, "192.0.2.20", "02:00:00:00:00:20")
        self.assertEqual(resolve_arp(cache, "192.0.2.20"), "02:00:00:00:00:20")

    def test_learning_new_mac_updates_binding(self):
        cache = {"192.0.2.20": "02:00:00:00:00:20"}
        learn_arp(cache, "192.0.2.20", "02:00:00:00:00:99")
        self.assertEqual(cache["192.0.2.20"], "02:00:00:00:00:99")

    def test_host_answers_only_for_its_target_ip(self):
        self.assertTrue(should_answer_arp("192.0.2.10", "192.0.2.10"))
        self.assertFalse(should_answer_arp("192.0.2.11", "192.0.2.10"))


if __name__ == "__main__":
    unittest.main()
