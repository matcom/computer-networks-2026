"""Starter package for the M04 local-networks lab."""
