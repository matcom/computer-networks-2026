"""Deterministic Ethernet learning-switch and ARP-cache model for M04."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Optional, Tuple

BROADCAST = "ff:ff:ff:ff:ff:ff"


@dataclass(frozen=True)
class Frame:
    src: str
    dst: str
    payload: bytes = b""


class LearningSwitch:
    """A small transparent learning bridge.

    TODO: learn source MACs and decide whether to forward, filter, or flood.
    The returned tuple contains egress port names in deterministic sorted order.
    """

    def __init__(self, ports: Iterable[str]):
        self.ports = tuple(sorted(set(ports)))
        if len(self.ports) < 2:
            raise ValueError("a switch needs at least two ports")
        self.table: Dict[str, str] = {}

    def receive(self, frame: Frame, ingress_port: str) -> Tuple[str, ...]:
        raise NotImplementedError


def learn_arp(cache: Dict[str, str], ip: str, mac: str) -> None:
    """Learn/update an IP → MAC binding in-place."""
    raise NotImplementedError


def resolve_arp(cache: Dict[str, str], ip: str) -> Optional[str]:
    """Return a cached MAC or None when resolution is still required."""
    raise NotImplementedError


def should_answer_arp(target_ip: str, local_ip: str) -> bool:
    """Return whether a host should answer a basic ARP request for local_ip."""
    raise NotImplementedError
