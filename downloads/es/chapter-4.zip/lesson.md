![Cuatro hosts conectados a un switch Ethernet con aprendizaje y una tabla compacta de MAC a puerto.](assets/book/ch04-ethernet-switching.png)

*Figura — Un switch con aprendizaje observa direcciones de origen, registra estado MAC→puerto y usa ese estado para reenviar destinos conocidos, inundando solo cuando es necesario.*

## Por qué importa este capítulo

IP puede decidir que un paquete debe salir por una interfaz y un siguiente salto determinados, pero esa decisión todavía debe convertirse en **entrega local sobre un enlace real**.

En una LAN tipo Ethernet cooperan dos clases de estado distintas:

- el **host** mantiene información de vecinos, por ejemplo asociaciones de IP a dirección de enlace,
- el **conmutador (switch)** mantiene información de reenvío, por ejemplo asociaciones de MAC a puerto.

Confundir ambas tablas es una forma muy rápida de perderse al diagnosticar una LAN.

> **Deténgase y prediga.** Su laptop quiere enviar un paquete IP a un servidor en otro continente. ¿Qué MAC utiliza normalmente la primera trama Ethernet como destino: la del servidor remoto, la puerta de enlace local o ambas?
## 1. La entrega Ethernet es local al dominio de enlace

Una trama Ethernet contiene MAC de origen, MAC de destino y una carga útil, como un paquete IPv4 o IPv6.

La trama tiene significado en el dominio Ethernet actual. Cuando un router reenvía el paquete IP encapsulado hacia otro enlace Ethernet, construye una **nueva trama** apropiada para ese siguiente salto.

Por tanto:

```text
trama Ethernet: entrega del salto local
paquete IP:      destino de capa de red a través de saltos
```

Esta diferencia es la base para comprender switches, ARP, cachés de vecinos y límites de enrutamiento.

<aside id="history-m04" class="cn-book-note cn-history">
  <span class="cn-book-note-label">Historia</span>
  <strong>Ethernet nació en Xerox PARC</strong>
  <p>Bob Metcalfe desarrolló Ethernet en Xerox PARC en 1973, adaptando ideas de comunicación por paquetes sobre medios compartidos a una red local. Ethernet evolucionó después desde un medio coaxial compartido hasta la tecnología conmutada full-duplex que domina las LAN cableadas actuales.</p>
  <a class="cn-book-note-source" href="../../../history/ethernet-from-shared-medium-to-switches/">Leer la historia de diseño: Ethernet sobrevivió cambiando casi todo alrededor de su abstracción reconocible →</a>
  <a class="cn-book-note-source" href="https://www.internetsociety.org/internet/history-internet/brief-history-internet/">Fuente ↗</a>
</aside>

## 2. Unicast, broadcast y unicast desconocido son casos diferentes

Una trama unicast identifica una MAC de destino concreta.

Ethernet broadcast utiliza:

```text
ff:ff:ff:ff:ff:ff
```

Un switch simple inunda las tramas broadcast dentro del dominio, sujeto a controles de la red real.

Un **unicast desconocido** es diferente: posee una MAC de destino concreta, pero el switch todavía no ha aprendido qué puerto llega hasta esa dirección. Un switch con aprendizaje también inunda este caso porque no dispone de mejor información.

Ambos pueden producir flooding, pero por razones distintas:

```text
broadcast          → dirigido intencionalmente a todos
unicast desconocido → un destino, ubicación aún no aprendida
```

<aside id="curiosity-m04" class="cn-book-note cn-curiosity">
  <span class="cn-book-note-label">Curiosidad</span>
  <strong>Las colisiones clásicas de Ethernet son casi historia</strong>
  <p>CSMA/CD es famoso porque los nodos de Ethernet original compartían un dominio de colisión. En Ethernet conmutado full-duplex cada extremo suele tener su propio enlace, por lo que la detección de colisiones ya no forma parte de la operación normal, aunque sigue siendo importante para comprender la evolución de Ethernet.</p>
</aside>

## 3. Un switch con aprendizaje construye conocimiento de topología a partir de las direcciones de origen

Supongamos puertos `p1`, `p2` y `p3`.

Para cada trama recibida, un algoritmo simple es:

```text
1. aprender source_MAC → ingress_port
2. inspeccionar MAC de destino
3. ¿broadcast?              inundar otros puertos
4. ¿destino desconocido?    inundar otros puertos
5. ¿destino en ingress?     filtrar
6. en otro caso             reenviar al puerto aprendido
```

¿Por qué aprender desde el **origen**?

Porque recibir una trama por `p2` es evidencia directa de que la dirección de origen es alcanzable a través de `p2`. La dirección de destino solo indica dónde *quería* llegar el emisor, no dónde reside realmente ese destino.

> **Deténgase y prediga.** Un switch vacío recibe `A → B` por `p1`. ¿Qué puede aprender inmediatamente? ¿Qué puede inferir acerca de B?

Puede aprender `A → p1`. Todavía no conoce el puerto de B, por lo que inunda la trama.

<aside id="tip-m04" class="cn-book-note cn-tip">
  <span class="cn-book-note-label">Consejo práctico</span>
  <strong>Prediga primero la tabla del conmutador</strong>
  <p>Antes de ejecutar un experimento LAN, anote qué dirección MAC de origen debería aprenderse en cada puerto. Después prediga si el siguiente destino se reenviará por un solo puerto, se inundará o se filtrará.</p>
</aside>

## 4. Ejemplo resuelto — la tabla se vuelve más informativa con cada trama

Comience con una tabla vacía.

### Trama 1: `A → B` entra por `p1`

Aprender:

```text
A → p1
```

B es desconocido, por tanto la trama sale por `p2` y `p3`.

### Trama 2: `B → A` entra por `p2`

Aprender:

```text
A → p1
B → p2
```

A ya es conocido, por tanto únicamente `p1` recibe la trama.

### Trama 3: `C → A` entra por `p3`

Aprender:

```text
A → p1
B → p2
C → p3
```

A es conocido y la trama sale solamente por `p1`.

El switch ha construido estado útil de reenvío **sin protocolo explícito de registro de hosts**. El tráfico ordinario le proporcionó suficiente evidencia para reducir el flooding.
## 5. El estado aprendido debe cambiar cuando cambia la red

Suponga que A se desconecta de `p1` y más tarde transmite desde `p3`.

El siguiente evento de aprendizaje debe actualizar:

```text
A → p3
```

Los switches reales también eliminan entradas antiguas porque los hosts se mueven, los enlaces cambian y una observación vieja deja de ser confiable.

El laboratorio omite envejecimiento dependiente del reloj para mantener un comportamiento determinista. La idea conceptual permanece: **el estado de reenvío en caché tiene una vida útil y puede quedar obsoleto**.
## 6. ARP resuelve un problema distinto del aprendizaje del switch

Un host ya ha elegido una dirección IPv4 de siguiente salto, pero necesita una MAC de destino para transmitir por Ethernet.

Si no existe la asociación en caché, ARP puede preguntar en el enlace local:

```text
Destino Ethernet: ff:ff:ff:ff:ff:ff
ARP: Who has 192.0.2.10? Tell 192.0.2.20
```

El propietario puede responder y el solicitante aprende:

```text
192.0.2.10 → 02:00:00:00:00:10
```

Observe las dos cachés independientes:

```text
caché de vecinos del host:  IP siguiente salto → MAC
reenvío del switch:         MAC → puerto
```

La primera ayuda al host a construir una trama. La segunda ayuda al switch a decidir por dónde reenviarla.
## 7. Los campos ARP y Ethernet no deben reducirse a “origen” y “destino”

Un mensaje ARP viaja **dentro** de una trama Ethernet. Durante el análisis distinga:

- MAC Ethernet de origen,
- MAC Ethernet de destino,
- dirección hardware del emisor ARP,
- dirección de protocolo del emisor ARP,
- dirección hardware del objetivo ARP,
- dirección de protocolo del objetivo ARP.

Esta precisión parece excesiva hasta que aparece tráfico malformado, obsoleto o falsificado. Nombrar los campos correctamente evita conclusiones incorrectas.
## 8. El siguiente salto no tiene por qué ser el destino IP final

Supongamos:

```text
host:    192.0.2.20/24
gateway: 192.0.2.1
server:  198.51.100.50
```

El servidor no pertenece al `/24` local, por lo que la decisión de ruta selecciona la puerta de enlace como siguiente salto.

El host resuelve:

```text
192.0.2.1 → MAC del gateway
```

no la MAC del servidor remoto.

La primera trama contiene conceptualmente:

```text
Destino Ethernet = MAC del gateway
Destino IP       = 198.51.100.50
```

La trama Ethernet termina en el router. El router extrae el paquete IP, realiza otra decisión de reenvío y lo encapsula en una nueva trama para el enlace siguiente.

> **Regla de razonamiento:** primero elija el siguiente salto IP; después pregunte cómo alcanzar ese siguiente salto en el enlace local.
## 9. Las cachés de vecinos mejoran eficiencia pero introducen estado obsoleto

Resolver cada siguiente salto para cada paquete sería costoso, por lo que los hosts mantienen información de vecinos en caché.

Ese estado introduce problemas habituales de sistemas:

- expiración,
- movilidad,
- observaciones en conflicto,
- asociaciones obsoletas,
- confianza.

En Linux:

```bash
ip neigh
```

muestra estado de vecinos y, con frecuencia, su estado de alcanzabilidad.

Es otro patrón de sistemas distribuidos: la caché hace rápido el camino común, pero la corrección depende de frescura e invalidación.
## 10. IPv6 utiliza Neighbor Discovery en lugar de ARP

IPv6 no utiliza ARP. Neighbor Discovery se apoya en ICMPv6 e incluye resolución de vecinos, descubrimiento de routers y funciones relacionadas con alcanzabilidad.

El concepto transferible importa más que memorizar un formato concreto:

```text
decisión de reenvío IP
        ↓
siguiente salto seleccionado
        ↓
resolución / alcanzabilidad en enlace local
        ↓
transmisión de trama
```

IPv4/ARP e IPv6/NDP implementan este patrón de forma diferente.
## 11. Los bucles convierten el flooding de mecanismo útil en modo de fallo

El aprendizaje presupone que una trama inundada llegará al destino sin circular indefinidamente.

Con enlaces Ethernet redundantes, una topología ingenua de capa 2 puede crear bucles. Tramas broadcast y unicast desconocidas pueden duplicarse y circular repetidamente, consumiendo capacidad y desestabilizando la red.

Ethernet de producción necesita una estrategia como:

- protocolos de control/prevención de bucles,
- topologías deliberadamente libres de bucles,
- arquitecturas que desplazan el multipath a otra capa.

Por eso “añadir otro cable para tener redundancia” no es automáticamente seguro en capa 2.
## 12. Las VLAN crean dominios lógicos de enlace separados

Un switch físico puede soportar varios dominios Ethernet lógicos mediante VLAN.

Esto significa que el aprendizaje MAC no es una tabla global única para todas las tramas del dispositivo. El estado de reenvío suele estar asociado a la VLAN o contexto correspondiente.

Las VLAN ayudan a aislar dominios broadcast y grupos administrativos, pero no eliminan la necesidad de enrutamiento entre ellos.
## 13. Observe el mecanismo en un host real

### Estado de interfaces

```bash
ip link
```

### Estado de vecinos

```bash
ip neigh
```

### Evidencia de paquetes

Capture un intercambio ARP cuando esté permitido y pregunte:

1. ¿el destino Ethernet de la solicitud es broadcast?
2. ¿qué host afirma poseer la IP objetivo?
3. ¿la respuesta es broadcast o unicast?
4. ¿cambia `ip neigh` después del intercambio?

El objetivo es correlacionar **evidencia en el enlace** con **estado del host**, no solamente reconocer nombres de protocolos.
## 14. Los límites de fallo se vuelven claros al separar ambas tablas

### Asociación de vecino incorrecta u obsoleta

El host posee una ruta IP plausible, pero construye tramas para la MAC equivocada.

### Entrada del switch incorrecta u obsoleta

La trama está bien direccionada, pero el switch la envía hacia un puerto incorrecto hasta que reaprende o expira la entrada.

### Falla la resolución ARP/NDP

El host sabe qué IP de siguiente salto desea, pero no logra establecer entrega local utilizable.

### Bucle de capa 2 o tormenta de broadcast

El tráfico repetido/inundado consume capacidad compartida y puede saturar dispositivos.

Desde la aplicación estos síntomas pueden parecer similares, pero la evidencia y la corrección son diferentes.
## 15. El estado de control local posee un modelo de confianza

ARP clásico no autentica criptográficamente una afirmación de asociación. Una red no puede asumir que toda asociación recibida es legítima solo porque su formato sea válido.

Las redes operativas pueden utilizar segmentación, inspección, estado estático, controles en switches o cifrado en capas superiores según su modelo de amenazas.

La idea arquitectónica es:

> **Todo mecanismo de control que acepte estado remoto necesita un modelo de confianza explícito.**
## Resumen del capítulo

Mantenga separadas estas dos clases de estado:

1. **El host asocia direcciones del siguiente salto con direcciones de enlace.**
2. **El switch asocia direcciones de enlace observadas con puertos.**
3. **El switch aprende del origen porque el puerto de entrada aporta evidencia de alcanzabilidad.**
4. **Broadcast y unicast desconocido pueden inundarse, pero por motivos diferentes.**
5. **Un destino IP remoto normalmente no implica una MAC remota en el primer salto.**
6. **Los routers sustituyen la encapsulación de enlace al cruzar de un enlace a otro.**
7. **El estado en caché puede quedar obsoleto y los caminos redundantes de capa 2 pueden crear bucles.**
8. **Los protocolos de control local dependen de supuestos de confianza.**

Antes de continuar, explique exactamente qué cambia y qué permanece lógicamente estable cuando un paquete IP atraviesa un router entre dos LAN Ethernet.
## Conexiones de sistemas

### [OS]

El kernel del host mantiene interfaces y vecinos y decide cuándo necesita resolución local.

### [ARCH]

NICs y switches pueden filtrar y reenviar en hardware, mientras drivers y DMA conectan las tramas con la memoria del host.

### [DIST]

Las cachés de vecinos y reenvío son estado distribuido que puede quedar obsoleto cuando cambia la movilidad o la topología.

### [SEC]

ARP/NDP y otros mecanismos de control local necesitan supuestos explícitos de confianza y diseño defensivo.

### [PERF]

El aprendizaje reduce flooding innecesario; los bucles y dominios broadcast excesivos consumen capacidad compartida.
## Autocomprobación

Sin volver a leer:

1. ¿Por qué un switch con aprendizaje actualiza su tabla desde la MAC de origen?
2. ¿Qué hace un switch nuevo con unicast desconocido y por qué?
3. Distinga caché de vecinos del host y tabla de reenvío del switch.
4. ¿Por qué un host normalmente resuelve la MAC de su gateway y no la de un servidor remoto?
5. ¿Qué cabeceras/direcciones se sustituyen cuando un router reenvía un paquete IP hacia otro enlace Ethernet?
6. Explique una forma en que el estado de enlace en caché puede quedar obsoleto.

Después ejecute las pruebas de switch/ARP de M04 y correlacione el modelo determinista con `ip neigh` o una captura local.
