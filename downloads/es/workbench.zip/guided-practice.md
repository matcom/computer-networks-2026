# Práctica guiada — Leer el estado del host antes de tocar la red

**Tiempo:** 8–10 minutos  
**Materiales:** una terminal Linux local; no requiere acceso a Internet

## Predicción

Antes de ejecutar comandos, escriba qué espera encontrar en un host normal:

1. Al menos una interfaz que no requiera una red física.
2. Una o más direcciones IP asociadas a interfaces.
3. Una decisión de encaminamiento para tráfico de loopback.
4. Cero o más sockets TCP en escucha.

Para cada elemento, indique qué objeto del sistema operativo debería aportar la evidencia: estado de interfaz, estado de direcciones, estado de rutas o estado de sockets.

## Ejemplo resuelto

Suponga que un host muestra una interfaz `lo` con `127.0.0.1/8`, una ruta para `127.0.0.0/8` mediante `lo` y un proceso escuchando en `127.0.0.1:8000`.

Una explicación útil no es “la red funciona”. Es más precisa:

- el kernel tiene una interfaz de loopback;
- la dirección pertenece a esa interfaz;
- la ruta mantiene el tráfico coincidente dentro del host;
- un proceso pidió al kernel aceptar conexiones TCP en el puerto 8000.

Cada afirmación depende de un tipo distinto de estado.

## Microexperimento guiado

Ejecute estos comandos locales y conserve solo las líneas necesarias:

```bash
ip -br link
ip -br addr
ip route get 127.0.0.1
ss -ltn
```

Responda:

1. ¿Qué interfaz transporta `127.0.0.1` en su host?
2. ¿La búsqueda de ruta hacia `127.0.0.1` necesita una puerta de enlace?
3. Elija un socket en escucha, si existe alguno. ¿Está asociado a loopback, a una dirección no-loopback concreta o a una dirección comodín?
4. ¿Qué comando puede demostrar que un proceso está escuchando? ¿Qué comandos no pueden demostrarlo?

No importa si los nombres de interfaces o la lista de sockets difieren entre máquinas. El objetivo es comprender el mecanismo, no memorizar una salida exacta.

## Evidencia que debe conservar

Conserve cuatro hechos breves: uno sobre interfaz, uno sobre dirección, uno sobre ruta y uno sobre socket. Para cada hecho anote el comando que lo sustenta y una afirmación que ese comando **no** puede demostrar. Debe poder explicar esos límites antes de pasar a la comprobación de conocimientos.
