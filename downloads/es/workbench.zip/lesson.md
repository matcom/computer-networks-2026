![Un taller de redes Linux con terminal, captura de paquetes, switch, router y herramientas locales de evidencia.](assets/book/workbench-observation.png)

*Figura — El taller mantiene la observación cerca del sistema: inspeccione el estado del host, siga los paquetes y conserve evidencia reproducible antes de modificar la red.*

## Por qué importa este capítulo

Un experimento de redes puede fallar porque el protocolo está mal, porque el host está mal configurado, porque falta una herramienta, porque una ruta apunta a un lugar inesperado o porque se está observando la interfaz equivocada.

Antes de construir protocolos de transporte, routers, política BGP, overlays o servicios distribuidos, necesitamos una forma repetible de responder una pregunta más sencilla:

> **¿Qué cree actualmente este host Linux acerca de la red y qué evidencia respalda esa creencia?**

M00 establece el vocabulario de evidencia que utilizaremos durante todo el libro. El objetivo no es memorizar cada comando, sino aprender qué vista del sistema responde qué pregunta.

> **Deténgase y prediga.** `curl https://example.com/` falla. ¿Eso permite saber si el fallo está en DNS, enrutamiento, TCP, TLS, HTTP o el servicio remoto? No. `curl` es útil precisamente porque atraviesa muchas dependencias, pero por la misma razón no identifica por sí solo la causa raíz.
## 1. El host local ya es un sistema de red completo

Incluso antes de crear una topología de laboratorio, un host Linux contiene estado como:

```text
procesos
  ↓
sockets
  ↓
interfaces + direcciones
  ↓
rutas + estado de vecinos
  ↓
colas / firewall / políticas
  ↓
NIC + driver + enlace físico/virtual
```

También contiene configuración del resolver, cachés locales, namespaces e interfaces virtuales.

Una solicitud Web puede atravesar varias de estas estructuras antes de que una trama salga de la máquina.

Este es el primer hábito de sistemas del curso:

> **No trate “la red” como una caja negra cuando el host ya expone estado que puede inspeccionarse.**

<aside id="history-m00" class="cn-book-note cn-history">
  <span class="cn-book-note-label">Historia</span>
  <strong>Unix hizo observable la red</strong>
  <p>Los cursos modernos de redes heredan una cultura de herramientas moldeada por Unix: pequeños programas muestran interfaces, rutas, sockets, capturas de paquetes y resolución de nombres como vistas diferentes del mismo sistema. La idea histórica importante no es memorizar un comando, sino inspeccionar el estado real en lugar de tratar la red como una caja negra.</p>
  <a class="cn-book-note-source" href="https://manpages.debian.org/unstable/manpages/standards.7.en.html">Fuente ↗</a>
</aside>

## 2. Las interfaces definen dónde puede asociar el kernel estado de red

Una interfaz es un punto de conexión de red visible para el sistema operativo. Puede representar:

- loopback,
- Ethernet o Wi-Fi físico,
- un extremo de Ethernet virtual,
- un bridge,
- un túnel,
- un dispositivo VPN,
- una conexión de contenedor o máquina virtual.

Inspeccione con:

```bash
ip link
ip address
```

Formule cuatro preguntas:

1. ¿La interfaz existe y está operativa?
2. ¿Qué direcciones y prefijos tiene?
3. ¿Es la interfaz que realmente selecciona la ruta?
4. ¿Está en el namespace que usted supone?

Nombres como `eth0` son convenciones, no verdades universales. Inspeccione siempre la máquina real.
## 3. Loopback es un camino real de protocolos sin red física

La interfaz de loopback permite utilizar IP y transporte normalmente sin enviar paquetes a un medio externo.

Los experimentos con localhost son útiles porque conservan:

- semántica de sockets,
- estado de transporte,
- framing de aplicación,
- gran parte de los caminos de código del kernel,

mientras eliminan variables como Wi-Fi, switches, routers y enrutamiento de Internet.

Un experimento localhost exitoso demuestra menos que uno remoto, pero muchas veces demuestra exactamente la capa que necesitamos aislar primero.

<aside id="curiosity-m00" class="cn-book-note cn-curiosity">
  <span class="cn-book-note-label">Curiosidad</span>
  <strong>Su computadora puede comunicarse consigo misma</strong>
  <p>La interfaz de loopback permite utilizar la pila completa de IP y transporte sin que un paquete salga de la máquina. Por eso los experimentos con localhost son tan útiles: ejercitan mecanismos reales de sockets y protocolos eliminando la red física del experimento.</p>
</aside>

## 4. Direcciones y prefijos describen identidad local y ámbito de enrutamiento

Una dirección como:

```text
192.0.2.20/24
```

contiene una dirección y una longitud de prefijo.

En M00 basta reconocer que la longitud del prefijo influye en qué destinos se consideran directamente conectados y cuáles requieren otra ruta o gateway.

Inspeccione con:

```bash
ip address
```

Capítulos posteriores formalizan subnetting y longest-prefix matching. Aquí el objetivo es aprender a leer el estado que ya mantiene el kernel.
## 5. El estado de rutas responde “¿hacia dónde iría este destino?”

Antes de transmitir un paquete IP, el kernel selecciona una ruta.

Comandos útiles:

```bash
ip route
ip route get 198.51.100.10
```

Una ruta puede identificar:

- prefijo de destino,
- siguiente salto,
- interfaz de salida,
- métrica o información de política.

`ip route get` es especialmente útil porque pregunta al kernel qué ruta utilizaría para un destino concreto.

Eso es evidencia más fuerte que mirar la tabla y adivinar.
## 6. La ruta por defecto es un fallback, no el destino final

Una línea como:

```text
default via 192.0.2.1 dev eth0
```

significa aproximadamente:

> “Para destinos que no coincidan con una ruta más específica, envíe hacia este siguiente salto mediante esta interfaz.”

El gateway suele ser el siguiente router, no el servidor remoto final.

M05 explicará por qué los prefijos más específicos ganan a la ruta por defecto. Por ahora distinga:

```text
destino IP final
≠
siguiente salto local
```
## 7. El estado de vecinos responde “¿cómo alcanzo ese siguiente salto en este enlace?”

Una ruta IP puede elegir un siguiente salto y una interfaz, pero la entrega tipo Ethernet todavía necesita una dirección de enlace.

Inspeccione:

```bash
ip neigh
```

Las entradas pueden aparecer como reachable, stale, incomplete, failed u otros estados del sistema.

La dependencia es:

```text
ruta IP utilizable
      +
resolución utilizable del siguiente salto
      ↓
se puede construir la trama de entrega local
```

M04 estudia ARP y Neighbor Discovery de IPv6 en detalle.
## 8. Los sockets conectan procesos de aplicación con estado de transporte

Los sockets son extremos de comunicación expuestos por el sistema operativo.

Vistas útiles:

```bash
ss -lntup
ss -tn
ss -un
```

Un socket TCP en escucha demuestra que el host local tiene un extremo esperando en una dirección/puerto dentro de su namespace y contexto de privilegios actuales.

No demuestra que:

- un cliente remoto tenga una ruta hasta él,
- un firewall permita el tráfico,
- TLS funcione,
- la aplicación responda correctamente.

Los puertos son extremos de transporte, no puertos físicos de switches.
## 9. Procesos, namespaces y privilegios cambian lo que puede verse y modificarse

Algunos detalles de sockets, operaciones de rutas, configuración de colas y capturas requieren privilegios elevados.

El curso no debe normalizar “ejecutar todo como root”.

Prefiera:

- privilegio mínimo,
- namespaces/contenedores desechables para cambios destructivos,
- teardown explícito,
- separación clara entre observar y modificar.

M12 utilizará namespaces como objetos de red de primera clase. En M00 basta recordar que dos procesos en el mismo host físico pueden ver redes diferentes.
## 10. Las herramientas DNS responden preguntas de nombres

`dig` expone evidencia orientada a DNS:

```bash
dig example.com
```

Inspeccione:

- nombre y tipo de consulta,
- registros de respuesta,
- TTL,
- código de respuesta,
- resolver/servidor utilizado.

Una respuesta DNS correcta demuestra algo sobre la resolución de nombres en ese punto de observación.

No demuestra que el servicio resultante sea alcanzable o esté sano.

Además, una aplicación puede utilizar bibliotecas de resolución, cachés locales, proxies o caminos de resolución distintos de una llamada directa a `dig`.
## 11. Las herramientas de aplicación son probes amplios extremo a extremo

`curl` es útil porque puede exponer varias etapas de una interacción HTTP(S):

```bash
curl -v https://example.com/
```

Según la solicitud y la compilación puede mostrar evidencia de:

- resolución de nombres,
- dirección elegida,
- conexión de transporte,
- negociación TLS,
- solicitud/respuesta HTTP.

Esa amplitud es fortaleza y limitación.

Cuando `curl` falla, pregunte qué dependencia anterior debe aislarse en lugar de tratar el mensaje final como causa raíz.
## 12. Una captura muestra tráfico en un punto de observación concreto

Herramientas comunes:

- `tcpdump`,
- TShark,
- Wireshark.

Por ejemplo:

```bash
tcpdump -ni any
```

Una captura es un registro temporal del tráfico visible **en ese punto de captura**.

No es un volcado de todo el sistema distribuido.

Un paquete puede existir en otro lugar sin aparecer allí, y offloads o encapsulación pueden hacer que el mismo intercambio lógico se vea distinto en interfaces diferentes.
## 13. Capture únicamente tráfico que esté autorizado a inspeccionar

Los experimentos del curso deben preferir:

- su propio host,
- loopback,
- namespaces/contenedores,
- PCAP suministrados,
- servicios controlados de laboratorio.

No capture tráfico de otros usuarios en redes compartidas.

Es una regla ética y también buen diseño experimental: el tráfico controlado es más fácil de interpretar.
## 14. Los timestamps son mediciones con supuestos

Los timestamps de paquetes son útiles para analizar latencia, pero dependen de:

- lugar de captura,
- fuente de reloj,
- resolución temporal,
- buffering de kernel/NIC,
- offloads,
- si el evento ocurrió antes o después del punto observado.

Que un número tenga seis decimales no significa que sea exacto a seis decimales.

M02 y M13 retomarán calidad y reproducibilidad de mediciones.
## 15. Los offloads pueden hacer que los paquetes visibles en el host difieran de los del medio físico

NICs y kernels modernos pueden realizar:

- checksum offload,
- segmentation offload,
- agregación de recepción,
- batching,
- otras aceleraciones.

Una captura dentro del host puede mostrar tamaños o estados de checksum diferentes de la representación final en el medio físico.

Eso no implica necesariamente un bug de Wireshark o de la NIC.

Es evidencia de que la captura ocurrió en una frontera concreta de la arquitectura.
## 16. Use una herramienta para responder una pregunta concreta

Un flujo útil es:

| Pregunta | Evidencia |
|---|---|
| ¿Qué interfaces/direcciones existen? | `ip address` |
| ¿Qué ruta elegiría el kernel? | `ip route get` |
| ¿Está resuelto el siguiente salto? | `ip neigh` |
| ¿Qué sockets escuchan o están conectados? | `ss` |
| ¿Qué devuelve DNS? | `dig` |
| ¿Qué hace la interacción de aplicación? | `curl -v` |
| ¿Qué paquetes son visibles aquí? | captura de paquetes |

El diagnóstico mejora cuando cada comando tiene un propósito definido **antes** de ejecutarse.

<aside id="tip-m00" class="cn-book-note cn-tip">
  <span class="cn-book-note-label">Consejo práctico</span>
  <strong>Haga una pregunta por herramienta</strong>
  <p>Use `ip address` para la identidad de las interfaces, `ip route` para las decisiones de reenvío, `ss` para sockets y una captura para observar los bytes en la red. El diagnóstico mejora cuando cada comando responde una pregunta concreta.</p>
</aside>

## 17. Git y el flujo del curso son local-first

Git no requiere GitHub.

Un estudiante puede trabajar completamente offline con:

```bash
git init
git status
git add ...
git commit ...
git log
```

Un repositorio remoto añade colaboración, respaldo y CI opcional, pero el control de versiones sigue siendo local.

Por diseño, una conectividad deficiente o inexistente no debe impedir el trabajo principal del laboratorio.
## 18. Exportar una tarea crea un workspace independiente

Descargue el ZIP del laboratorio enlazado en el capítulo actual y extráigalo en un directorio propio. Trabaje dentro de `assignment/`; no necesita acceso al repositorio privado del curso.

El workspace exportado incluye el material necesario, por ejemplo:

- instrucciones/objetivos,
- código inicial,
- pruebas públicas,
- directorio de pruebas del estudiante,
- test runner,
- Makefile,
- fixtures/topologías referenciadas,
- workflow CI opcional cuando esté configurado.

El repositorio exportado debe seguir siendo útil sin acceso al monorepo del curso.
## 19. Las pruebas transparentes forman parte ejecutable de la especificación

El runner público admite comandos como:

```bash
make list-tests
make test
make test-case CASE=<substring>
```

Se espera que los estudiantes lean las pruebas.

Una prueba transparente no es una fuga del sistema de evaluación. Es un ejemplo concreto de comportamiento que puede estudiarse, extenderse y reproducirse.

El objetivo es comprender el contrato del protocolo/sistema, no adivinar casos ocultos.
## 20. Las pruebas del estudiante convierten edge cases descubiertos en conocimiento reutilizable

Las tareas de programación incluyen:

```text
tests/official/
tests/student/
```

Cuando un estudiante descubre una nueva condición límite, debe convertirla en una prueba bajo `tests/student/`.

Eso cambia la pregunta de:

> “¿Qué truco usará el evaluador?”

hacia:

> “¿Qué comportamiento todavía no he especificado o probado?”

Esto se parece mucho más a ingeniería de sistemas real.
## 21. CI opcional debe repetir la verdad local, no crear un segundo universo de evaluación

Una tarea exportada puede incluir GitHub Actions.

Su propósito es conveniencia y práctica con CI, no una fuente oculta de corrección.

El invariante es:

```text
pruebas transparentes locales == pruebas CI opcionales
```

Si GitHub no está disponible, la tarea sigue siendo completamente comprobable en local.
## 22. Verifique capacidades sin exigir todas las herramientas desde el primer día

Ejecute:

```bash
for tool in python3 git ip ss curl dig tcpdump; do
  command -v "$tool" || true
done
```

El núcleo del curso necesita una base pequeña como Python y Git.

El resto de herramientas es específico por módulo. No aporta valor pedagógico obligar a instalar FRRouting, containerlab, Scapy, Wireshark y cada utilidad diagnóstica antes del módulo que realmente las usa.

Una herramienta opcional ausente es una capacidad del entorno que debe registrarse, no automáticamente un fallo del concepto de red estudiado.
## 23. Investigación resuelta — explique una solicitud Web exitosa usando varias capas de evidencia

Suponga que:

```bash
curl https://example.com/
```

funciona.

Recoja evidencia como:

```bash
ip address
ip route
ip route get <resolved-IP>
ip neigh
ss -tn
dig example.com
curl -v https://example.com/
```

y, cuando esté autorizado, una captura estrecha.

Construya una secuencia:

```text
consulta de nombre / resolución cacheada
      ↓
dirección de destino seleccionada
      ↓
ruta local + siguiente salto
      ↓
conexión de transporte
      ↓
establecimiento TLS/seguridad
      ↓
solicitud/respuesta HTTP
```

Después etiquete cada observación por su fuente:

```text
evidencia de aplicación
estado del kernel
evidencia de paquetes
```

El ejercicio está completo cuando puede explicar no solo **qué ocurrió**, sino **qué observación respalda cada afirmación**.
## 24. Fallos frecuentes de entorno y razonamiento

### Falta un comando

Es un problema de entorno/herramientas hasta que la evidencia indique otra cosa. Use la alternativa documentada o el fixture determinista suministrado.

### No hay privilegio para capturar

La aplicación puede seguir funcionando. Use PCAP/datasets proporcionados o un namespace/contenedor controlado donde la captura esté permitida.

### No hay conectividad con GitHub

Git local y las pruebas transparentes locales siguen disponibles por diseño.

### Se asume un nombre fijo de interfaz

La máquina puede utilizar `enp...`, `wlp...`, interfaces virtuales o nombres propios del namespace. Inspeccione estado real.

### Se trata un host virtualizado como “red incorrecta”

VMs, contenedores, VPN y cloud añaden legítimamente interfaces, rutas, NAT y túneles. Forman parte del sistema.

### Se utiliza un solo comando como prueba de todo el camino

Un resultado correcto de `dig`, `ping` o `ss` posee un ámbito de autoridad específico. No permita que el éxito de una capa represente todas las demás.
## Resumen del capítulo

M00 establece la disciplina de evidencia del libro:

1. **El host ya expone estado de red inspeccionable.**
2. **Interfaces, direcciones, rutas, vecinos, sockets, DNS, herramientas de aplicación y capturas responden preguntas diferentes.**
3. **Una ruta por defecto es un fallback de siguiente salto, no el destino remoto final.**
4. **Las capturas son observaciones locales cuya interpretación depende del punto de captura y de los offloads.**
5. **Use privilegio mínimo y entornos controlados.**
6. **Git, pruebas y tareas siguen un modelo local-first.**
7. **Las pruebas transparentes son especificación ejecutable y las pruebas del estudiante conservan edge cases descubiertos.**
8. **Una investigación sólida declara qué pretende demostrar cada comando antes de ejecutarlo.**

Antes de continuar, elija una interacción de red exitosa de su máquina y explíquela usando al menos una evidencia de aplicación, una pieza de estado del kernel y una observación de paquetes o fixture suministrado.
## Conexiones de sistemas

### [OS]

Interfaces, rutas, vecinos, sockets, procesos, namespaces, permisos y hooks de captura son estado del sistema operativo.

### [ARCH]

NICs, drivers, DMA, interrupciones, colas, segmentación, checksums y offloads explican por qué la evidencia visible en host puede diferir de un modelo abstracto de paquetes.

### [DIST]

Incluso una solicitud Web sencilla atraviesa componentes de nombres, transporte, seguridad y servicio que pueden fallar de forma independiente.

### [SEC]

Privilegio mínimo, autorización de captura, tráfico cifrado y evidencia controlada por el endpoint establecen límites importantes de observación.

### [PERF]

Las afirmaciones posteriores de rendimiento dependen de timestamps correctos, descripción de carga, ubicación de captura, contadores y contexto del sistema.
## Autocomprobación

Sin volver a leer:

1. ¿Qué comando pregunta al kernel por la selección de ruta hacia un destino concreto?
2. Distinga estado de `ip route` y de `ip neigh`.
3. ¿Qué demuestra un socket en escucha y qué no demuestra?
4. ¿Por qué `curl` es útil pero demasiado amplio para diagnosticar una causa raíz por sí solo?
5. ¿Por qué toda captura debe registrar interfaz/punto de captura?
6. ¿Qué trabajo principal del curso sigue siendo posible sin acceso a GitHub?
7. ¿Dónde deben añadirse las pruebas transparentes propias del estudiante?
8. Dé una razón por la que una captura del host puede diferir de los paquetes del medio físico.
9. ¿Por qué una herramienta opcional ausente es un hecho del entorno y no automáticamente un fallo del protocolo?

Después complete el laboratorio workbench de M00 y conserve sus notas de línea base para el trabajo de diagnóstico en M13.
