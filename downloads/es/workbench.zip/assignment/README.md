Este módulo inicial es deliberadamente observacional. Construirá un flujo de trabajo local y guardará una instantánea de referencia a la que podrá volver cuando un experimento posterior falle.

## 1. Verifique el medio ambiente

En su terminal Linux:

```bash
for tool in python3 git ip ss curl dig tcpdump; do
  command -v "$tool" || true
done
```

Registre qué herramientas de red opcionales están presentes. No instale todo de forma preventiva; los módulos posteriores declaran sus propios requisitos.

## 2. Predecir antes de inspeccionar

Antes de ejecutar cada comando, escriba lo que espera que revele:

```bash
ip address
ip route
ss -lntup
```

Para cada uno, identifique si la información pertenece principalmente a la aplicación, socket/OS, red o vista de enlace. Después prediga qué cambiará en `ss` cuando inicie un servicio HTTP local en el paso siguiente.

## 3. Siga un intercambio de aplicaciones

El recorrido obligatorio funciona sin acceso a Internet. En una terminal, inicie un servicio HTTP limitado a loopback:

```bash
python3 -m http.server 8000 --bind 127.0.0.1
```

En otra terminal, inspeccione el socket en escucha y realice una solicitud:

```bash
ss -lntp
curl -I http://127.0.0.1:8000/
```

Capture el intercambio de loopback con Wireshark/TShark o `tcpdump` cuando los permisos lo permitan. Si no puede capturar paquetes, conserve como evidencia obligatoria la salida de `ss` y las cabeceras de la respuesta HTTP.

Cuando exista conectividad a Internet y un resolver configurado, añada esta comparación opcional:

```bash
dig example.com
curl -I https://example.com/
```

Compare la evidencia DNS/HTTPS con el intercambio local, pero no trate la conectividad con `example.com` como requisito de corrección.

Su evidencia obligatoria debe identificar al menos:

- una interfaz local y su dirección IP,
- la interfaz de loopback,
- la ruta por defecto si existe,
- un socket TCP en escucha,
- un intercambio HTTP/TCP local,
- puertos de transporte local y del peer.

Si realizó la comparación conectada opcional, identifique además una consulta/respuesta DNS y el extremo de transporte remoto.

## 4. Git y pruebas locales

Conserve sus comandos y observaciones en un archivo de texto local. Inicialice un repositorio Git en su propio directorio de evidencias e inspeccione el estado de trabajo:

```bash
git init
git status
```

Los laboratorios de programación posteriores incluyen un ejecutor independiente y pruebas visibles en sus descargas. Este laboratorio observacional no requiere el código privado del curso ni un workflow de GitHub Actions.

## 5. Explicar

Cree una breve nota técnica que contenga comandos y evidencia de texto en lugar de capturas de pantalla. Responda:

1. ¿Qué información proporciona el kernel que no proporciona una captura de paquetes?
2. ¿Qué valores cambiaron entre el tráfico local y la comparación DNS/HTTPS, si realizó la extensión opcional?
3. ¿Qué podría aprender aun si GitHub no estuviera disponible durante todo el semestre?
4. ¿A qué herramienta recurriría primero si un nombre de host se resolviera pero fallara la conexión TCP?

No existe una suite automatizada de aprobado/reprobado para esta práctica. Aquí importa observar e interpretar correctamente; las tareas posteriores utilizan el marco de pruebas locales transparentes.