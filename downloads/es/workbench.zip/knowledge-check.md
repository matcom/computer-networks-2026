Responda antes de ejecutar el laboratorio.

1. ¿Qué comando usarías para inspeccionar las direcciones de la interfaz? ¿Selección de ruta local para un destino? ¿Estado vecino? ¿Estás escuchando sockets?
2. Explique la diferencia entre una ruta IP y una entrada vecina ARP/NDP.
3. ¿Por qué una captura de paquetes no puede indicarle cada estado dentro del proceso local o de un enrutador remoto?
4. ¿Qué información adicional proporciona `ss` que una captura de paquetes no puede proporcionarse directamente?
5. Si `curl` falla, ¿por qué "la red está cayendo" es un diagnóstico insuficiente?
6. ¿Qué partes del flujo de trabajo del curso siguen funcionando si GitHub no está disponible durante todo el semestre?
7. ¿Cuál es la diferencia entre `tests/official/` y `tests/student/` en una tarea exportada?
8. ¿Por qué conviene inspeccionar `make list-tests` en lugar de tratar las pruebas como un comportamiento secreto del evaluador?
9. Indique una razón por la que las descargas de NIC/kernel pueden hacer que una captura del lado del host difiera de la representación final del cable.

Después de responder, registre las herramientas disponibles en su terminal y siga el intercambio HTTP/TCP local por loopback del laboratorio. La comparación DNS/HTTPS conectada es opcional.
