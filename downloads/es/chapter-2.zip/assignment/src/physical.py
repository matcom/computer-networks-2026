"""Small deterministic physical-layer models used by the M15 laboratory."""


def serialization_delay_seconds(payload_bytes, bit_rate_bps):
    pass


def propagation_delay_seconds(distance_m, propagation_speed_mps):
    pass


def symbol_rate_baud(bit_rate_bps, bits_per_symbol):
    pass


def snr_db(signal_power, noise_power):
    pass


def nrz_encode(bits, low=-1.0, high=1.0):
    pass


def nrz_decode(levels, threshold=0.0):
    pass


def manchester_encode(bits, low=-1.0, high=1.0):
    """Return two half-symbol levels per bit using one teaching convention.

    0 -> high, low
    1 -> low, high
    """
    pass
