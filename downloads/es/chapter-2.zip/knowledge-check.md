1. Un enlace de 10 Gb/s sustituye a uno de 1 Gb/s sobre la misma fibra. ¿Qué término cambia directamente: serialización, propagación, ambos por igual o ninguno?
2. Un esquema tiene cuatro estados de símbolo distinguibles. ¿Cuántos bits puede representar idealmente cada símbolo?
3. Explique por qué una larga secuencia sin transiciones puede dificultar la recuperación de reloj en una codificación sencilla.
4. Distinga **tasa de bits**, **tasa de símbolos** y **ancho de banda espectral**, incluyendo las unidades.
5. Una trama de 1500 bytes se transmite a 100 Mb/s. Calcule su retardo de serialización.
6. Un camino de 1000 km tiene velocidad de propagación `2 × 10^8 m/s`. Calcule el retardo de propagación de ida.
7. ¿Por qué una modulación de orden superior puede dejar de ser confiable cuando disminuye SNR?
8. Indique una limitación física importante del cobre, la fibra y la radio.
9. ¿Por qué una tasa PHY de Wi-Fi puede ser mucho mayor que el goodput de aplicación?
10. ¿Qué evidencia pueden mostrar `ethtool` o las herramientas Wi-Fi y qué detalles físicos quedan fuera de la visibilidad normal del OS?
