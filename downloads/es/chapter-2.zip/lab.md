Este laboratorio convierte la capa física en un modelo determinista. No simulará un PHY completo de radio o Ethernet; implementará los cálculos y pasos mínimos que hacen ejecutables las distinciones del capítulo.

## 1. Prediga antes de programar

Sin ejecutar código, responda:

1. ¿Cambiar de 100 Mb/s a 1 Gb/s modifica la velocidad de propagación en el mismo cable?
2. Si un símbolo representa dos bits, ¿qué ocurre con la tasa de símbolos necesaria para la misma tasa de bits?
3. Si el ruido desplaza una muestra al otro lado del umbral de decisión, ¿qué tipo de error aparece?
4. ¿Por qué una tasa PHY anunciada puede superar el goodput útil de aplicación?

## 2. Implemente el modelo determinista

Complete `src/physical.py`.

Las pruebas públicas cubren:

- retardo de serialización,
- retardo de propagación,
- conversión entre tasa de bits y símbolos,
- SNR en decibelios,
- codificación/decodificación NRZ de dos niveles,
- codificación Manchester didáctica,
- manejo de entradas inválidas.

Ejecute:

```bash
python3 scripts/run_tests.py --list
python3 scripts/run_tests.py
```

En una tarea exportada:

```bash
make list-tests
make test
```

## 3. Explique un camino físico real

Elija una interfaz real disponible. Puede ser Ethernet, Wi-Fi, una interfaz virtual de VM/contenedor u otra interfaz que pueda inspeccionar de forma segura.

Registre únicamente lo que el OS pueda mostrar con herramientas como:

```bash
ip link
ethtool <interfaz>   # cuando esté soportado

iw dev               # en sistemas Wi-Fi, cuando esté disponible
```

Distinga:

- estado visible por software,
- propiedades de enlace negociadas/reportadas,
- hechos físicos que puede inferir,
- detalles de la forma de onda que no puede observar directamente con herramientas normales del OS.

## 4. Compare serialización y propagación

Calcule ambos términos para:

```text
trama de 1500 bytes
1 Gb/s
distancia de 2000 km
velocidad de propagación de 2 × 10^8 m/s
```

Después repita solamente la serialización a 100 Gb/s.

Explique por qué la capacidad cambia enormemente mientras el límite geográfico apenas cambia.

## 5. Decodifique una señal didáctica con ruido

Use su codificador NRZ para generar niveles para:

```text
1 0 1 1 0 0 1
```

Modifique manualmente un nivel recibido para que cruce el umbral. Decodifique de nuevo e identifique exactamente qué bit cambia.

El modelo es deliberadamente simple. El objetivo es hacer visible la decisión del receptor antes de introducir técnicas reales de codificación, modulación y detección.

## 6. Cierre con una explicación de sistemas

Responda la pregunta guía:

> ¿Cómo convierte una computadora bits en señales físicas que otra máquina puede recuperar de forma confiable?

Debe utilizar correctamente:

```text
bit
símbolo
señal / forma de onda
medio
tasa de bits
tasa de símbolos
ruido
decisión del receptor
PHY
MAC
```

El siguiente capítulo, Rendimiento de red, utilizará estas distinciones para construir modelos de retardo y throughput extremo a extremo.
