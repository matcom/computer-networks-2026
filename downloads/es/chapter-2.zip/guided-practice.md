# Práctica guiada — Convertir bits en una señal docente con ruido

**Tiempo:** 10–12 minutos  
**Materiales:** papel, calculadora o un editor de texto; no requiere acceso a Internet

## Predicción

Tome la secuencia de bits:

```text
1 0 1 1 0 0 1 0
```

Use esta codificación docente simple: bit `1 → +1 V`, bit `0 → -1 V`, una muestra por intervalo de bit. Prediga la secuencia ideal de muestras. Después prediga qué hará un receptor con umbral de decisión `0 V` si un ruido pequeño altera las muestras sin cruzar ese umbral.

## Ejemplo resuelto

Las muestras ideales son:

```text
+1  -1  +1  +1  -1  -1  +1  -1
```

Suponga ahora que el canal produce:

```text
+0.7  -0.6  +1.2  +0.3  -1.1  -0.4  +0.8  -0.9
```

Con umbral `0 V`, las muestras positivas se decodifican como `1` y las negativas como `0`, por lo que se recuperan correctamente los ocho bits pese al ruido.

Si la cuarta muestra pasara de `+0.3 V` a `-0.1 V`, el receptor cometería un error de bit. El ruido importa porque el receptor observa una señal física, no bits abstractos.

## Microexperimento guiado

Decodifique primero estas muestras con el mismo umbral de `0 V`:

```text
+0.9  -0.2  +0.1  -0.1  -0.8  +0.6  +0.4  -0.7
```

Escriba la secuencia de ocho bits recuperada y marque qué muestras están más cerca del límite de decisión.

Compare después tasa de símbolos y tasa de bits. Suponga una modulación con cuatro símbolos distinguibles que asigna dos bits a cada símbolo:

```text
00 → S0
01 → S1
10 → S2
11 → S3
```

Codifique `10110010` como símbolos. ¿Cuántos símbolos se transmiten? Si la tasa de símbolos es `1 Mbaud`, ¿cuál es la tasa bruta de bits en este mapeo idealizado?

Finalmente compare dos retardos para una trama de 1500 bytes transmitida sobre un enlace de `10 Mb/s` de `200 km`, usando velocidad de propagación `2 × 10^8 m/s`:

```text
serialización = bits_de_trama / tasa_del_enlace
propagación = distancia / velocidad_de_propagación
```

Calcule ambos y diga cuál cambia si la tasa del enlace pasa a `100 Mb/s` mientras la distancia y el medio permanecen iguales.

## Evidencia que debe conservar

Conserve la decodificación de muestras ruidosas, el mapeo bits→símbolos y los dos cálculos de retardo. Debajo escriba una frase que explique la cadena `bits → símbolos → señal física → observación con ruido → bits decodificados`. Ese es el mecanismo físico que los capítulos posteriores de Ethernet e IP tratarán como un enlace.
