![Un cliente y un servidor se comunican a través de redes locales e IP enrutado mientras las responsabilidades de protocolo permanecen en capas.](assets/book/ch01-internet-architecture.svg)

*Figura — Un intercambio de aplicación atraviesa límites de host, enlace local, enrutamiento y extremo remoto. El mismo camino puede leerse como dispositivos en el espacio y como responsabilidades de protocolo en capas.*

## Por qué importa este capítulo

Un navegador puede cargar una página en una fracción de segundo, pero esa aparente simplicidad oculta varios sistemas que cooperan: una aplicación, el sistema operativo, una red local, uno o más routers, otras redes administradas de forma independiente y un servicio remoto. La habilidad importante no es memorizar nombres de protocolos. Es aprender a preguntar **qué componente actúa, qué estado utiliza y qué evidencia permite observarlo**.

Este capítulo establece el modelo que reutilizaremos a lo largo del resto del libro.

> **Deténgase y prediga.** Escriba `https://example.com/` en un navegador. Antes de continuar, enumere al menos cuatro sistemas o mecanismos de protocolo que pueden intervenir antes de que aparezca el primer byte de la respuesta.

<aside id="history-m01" class="cn-book-note cn-history">
  <span class="cn-book-note-label">Historia</span>
  <strong>El primer mensaje de ARPANET fue solamente «LO»</strong>
  <p>El 29 de octubre de 1969, UCLA intentó enviar `LOGIN` al Stanford Research Institute. El sistema remoto falló después de las dos primeras letras, por lo que el primer mensaje transportado por ARPANET fue `LO`. Poco después se envió correctamente el comando completo.</p>
  <a class="cn-book-note-source" href="../../../history/packet-switching-to-internet/">Leer la historia de diseño: Por qué la conmutación de paquetes sustituyó el modelo mental de la red telefónica →</a>
  <a class="cn-book-note-source" href="../../../history/open-architecture-and-tcp-ip/">Leer la historia de diseño: Por qué TCP/IP separó reenvío y confiabilidad y mantuvo deliberadamente modesta a la red →</a>
  <a class="cn-book-note-source" href="https://newsroom.ucla.edu/releases/internet-50-symposium-ucla">Fuente ↗</a>
</aside>

## 1. Una acción de aplicación atraviesa muchos límites

Una primera aproximación útil es:

```text
aplicación
    ↓
API de red del sistema operativo
    ↓
estado de transporte
    ↓
reenvío IP
    ↓
enlace local
    ↓
routers y otros enlaces
    ↓
host remoto
    ↓
aplicación remota
```

Ningún componente necesita comprender el intercambio completo. La aplicación no tiene que saber cómo Ethernet codifica una trama. Un router normalmente no necesita saber qué elemento HTML producirá una solicitud. El servidor remoto no necesita una copia de la tabla de reenvío de cada router intermedio.

Esta separación es una de las razones por las que Internet puede escalar: los componentes cooperan mediante **interfaces y contratos de protocolo**, no mediante una implementación global compartida.
## 2. La conmutación de paquetes cambia reserva por compartición

El tráfico de Internet se divide en paquetes que comparten los enlaces a lo largo del tiempo. Normalmente no se reserva capacidad de forma permanente para cada aplicación antes de permitirle transmitir.

Si un enlace de salida de 1 Gb/s está libre, un solo flujo puede utilizar gran parte de su capacidad. Si muchos flujos se activan al mismo tiempo, sus paquetes compiten por una tasa de servicio finita. De ahí aparecen tres efectos recurrentes:

- **retardo de cola** mientras los paquetes esperan para transmitirse,
- **pérdida** cuando se agotan los buffers u otros recursos,
- **rendimiento variable** porque el tráfico competidor cambia con el tiempo.

La conmutación de paquetes permite compartir muy bien la capacidad, pero no garantiza latencia constante.

> **Deténgase y prediga.** Dos aplicaciones comparten el mismo enlace de salida. ¿Debe la red reservar exactamente la mitad para cada una antes de que cualquiera pueda transmitir? ¿Qué cambia si ambas envían a máxima velocidad al mismo tiempo?

M02 cuantificará propagación, serialización, colas, throughput y producto ancho de banda-retardo. M09 estudiará cómo reaccionan los extremos cuando la capacidad compartida se congestiona.
## 3. Las capas son contratos, no cajas independientes

La estratificación funciona cuando una capa ofrece un servicio mediante una interfaz más simple que los detalles necesarios para implementarlo.

Un programa puede utilizar un socket sin decidir cómo Wi-Fi o Ethernet representan los bits. IP puede transportar paquetes sobre muchas tecnologías de enlace. Los protocolos de transporte pueden ofrecer comunicación entre procesos sin obligar a las aplicaciones a implementar el enrutamiento.

Un modelo compacto es:

```text
aplicación       significado: nombres, solicitudes, respuestas
transporte       comunicación entre procesos
IP               reenvío entre redes heterogéneas
enlace           entrega de un salto en el medio actual
físico           señales y transmisión
```

Las capas no son máquinas separadas. Un host normalmente procesa todas ellas. Un router también tiene interfaces, colas, comportamiento de enlace, un sistema operativo o plano de control y, en algunos casos, servicios de aplicación.

La estratificación es una abstracción, no una regla para ignorar las capas inferiores. Problemas de rendimiento, MTU, pérdidas, offloads y límites de seguridad obligan con frecuencia a razonar a través de varias capas.
## 4. La encapsulación transporta el estado que necesita cada capa

Supongamos que una aplicación produce la carga útil `P`. Conceptualmente, las capas inferiores la rodean con sus propios metadatos:

```text
aplicación:                       [ P ]
transporte:       [ cabecera transp. | P ]
IP:          [ cabecera IP | cabecera transp. | P ]
enlace: [ cabecera enlace | cabecera IP | cabecera transp. | P | tráiler ]
```

Las cabeceras no son simples etiquetas. Contienen información utilizada por una capa concreta: puertos, números de secuencia, direcciones de red, límites de saltos, identificadores de protocolo, sumas de verificación y otros estados.

Una consecuencia importante es que **no todos los dispositivos necesitan inspeccionar todas las cabeceras**. El reenvío IP básico utiliza información de la capa de red. Un router normal no necesita interpretar un método HTTP para elegir el siguiente salto.

Cuando un paquete pasa de un enlace a otro, la trama local puede cambiar aunque el paquete IP lógico continúe hacia el mismo extremo remoto.

> **Ejemplo resuelto.** Un paquete cruza cinco routers entre dos hosts conectados mediante Ethernet. Las direcciones IP de origen y destino normalmente se conservan extremo a extremo, mientras que cada salto Ethernet puede utilizar una pareja distinta de direcciones. Por eso la dirección MAC de un servidor remoto de Internet suele ser irrelevante para su host local.
## 5. Internet es una red de redes

La palabra *Internet* es literal: es una **interred**. Miles de redes administradas de forma independiente cooperan mediante protocolos comunes.

Conviene distinguir:

- **Host:** máquina que ejecuta aplicaciones de extremo y una pila de red.
- **Enlace:** dominio de comunicación o salto entre interfaces.
- **Conmutador (switch):** dispositivo que normalmente reenvía tramas dentro de un dominio de enlace.
- **Router:** dispositivo que reenvía paquetes IP entre redes.
- **Sistema Autónomo (AS):** conjunto de redes bajo una política común de administración y enrutamiento.
- **Servicio:** funcionalidad de aplicación que puede estar replicada en muchos hosts, regiones o proveedores.

Una ruta puede atravesar una red doméstica o universitaria, un proveedor de acceso, proveedores de tránsito, puntos de intercambio de Internet y la red de un proveedor de contenidos. Esas organizaciones no comparten una única configuración global de routers. Interoperan porque acuerdan un comportamiento común de los protocolos.

### La estructura administrativa importa

La ruta físicamente más corta no siempre es la ruta seleccionada por Internet. Las relaciones comerciales, la política, los fallos, la capacidad y la ingeniería de tráfico influyen en el enrutamiento. M07 desarrolla esta idea con BGP.

<aside id="curiosity-m01" class="cn-book-note cn-curiosity">
  <span class="cn-book-note-label">Curiosidad</span>
  <strong>Internet no es una sola red</strong>
  <p>Una solicitud del navegador puede atravesar una LAN doméstica o universitaria, un proveedor de acceso, redes de tránsito, puntos de intercambio y la red de un proveedor de contenido antes de llegar al servicio. Lo que hace que todo parezca una sola Internet es el acuerdo sobre protocolos interoperables, no la propiedad de una única organización.</p>
</aside>

## 6. La cintura estrecha permite evolucionar por encima y por debajo

La arquitectura de Internet suele representarse como un reloj de arena:

```text
muchas aplicaciones
        ↓
opciones de transporte
        ↓
        IP
        ↓
muchas tecnologías de enlace
```

IP es la capa común estrecha. Muchas aplicaciones pueden utilizarla por encima y muchas tecnologías de enlace pueden transportarla por debajo.

Este diseño reduce la coordinación necesaria. Una nueva aplicación no exige que todos los switches Ethernet, redes Wi-Fi, enlaces de fibra o sistemas de radio comprendan su semántica. De forma similar, una nueva tecnología de enlace puede transportar aplicaciones IP existentes sin rediseñarlas.

La contrapartida es un minimalismo intencional: la capa de red no intenta proporcionar todas las propiedades que una aplicación podría desear.
## 7. El estado debe residir donde exista suficiente información

El **argumento extremo a extremo** pregunta dónde puede implementarse una función de forma completa y correcta.

Imagine que una capa inferior de red promete una transferencia "confiable". ¿Puede el emisor concluir que un archivo ya está correcto en el disco del receptor? No necesariamente. La corrupción podría ocurrir antes de transmitir, después de recibir, en el almacenamiento o dentro de la aplicación. Solo los extremos poseen el contexto suficiente para verificar el resultado final a nivel de aplicación.

Esto no significa que "la red no deba hacer nada". Las capas inferiores pueden ofrecer retransmisión, checksums, control de congestión, reenvío, filtrado y muchos otros mecanismos útiles. El principio se refiere a **dónde puede establecerse la corrección final**.

Ejemplos que finalmente requieren conocimiento del extremo incluyen:

- integridad a nivel de aplicación,
- semántica de autenticación y cifrado,
- determinar si un reintento es seguro,
- comprobar si una transacción realmente terminó.

Esta idea reaparecerá en transporte, TLS, sistemas distribuidos, reintentos y replicación.
## 8. El estado de control y el estado de reenvío cumplen funciones distintas

Otra separación útil es entre **plano de control** y **plano de datos**.

El plano de control aprende o calcula información como las rutas. El plano de datos utiliza el estado de reenvío instalado para procesar paquetes rápidamente.

Conceptualmente:

```text
información de enrutamiento / política
                 ↓
          plano de control
                 ↓
         tabla de reenvío
                 ↓
           plano de datos
                 ↓
          siguiente salto
```

OSPF, BGP, la configuración estática o un controlador definido por software pueden influir en el estado de reenvío. El reenvío de paquetes utiliza después esa tabla repetidamente para procesar paquetes individuales.

Separar ambos papeles ayuda a entender por qué un router puede continuar reenviando tráfico con una tabla existente mientras los protocolos de enrutamiento siguen intercambiando información de control.
## 9. Siga un intercambio real utilizando evidencia

Supongamos que el usuario solicita `https://example.com/`. Una cronología útil para diagnosticar el sistema no es "Internet hizo algo", sino una secuencia de decisiones observables.

### Paso 1 — obtener un destino

El resolver necesita una dirección para el nombre, salvo que exista una respuesta válida en caché.

```bash
dig example.com
```

Esto muestra información de DNS. **No** revela la futura ruta de reenvío a través de todos los routers.

### Paso 2 — elegir una ruta local

El kernel decide cómo alcanzar el destino, con frecuencia mediante una puerta de enlace predeterminada.

```bash
ip route
ip route get <destination-IP>
```

Esto es evidencia del estado de enrutamiento local.

### Paso 3 — alcanzar el siguiente salto en el enlace local

En una LAN tipo Ethernet, el host normalmente necesita una dirección de enlace para el **siguiente salto**, no para el servidor remoto de Internet.

```bash
ip neigh
```

### Paso 4 — crear estado de transporte en los extremos

La aplicación abre estado de transporte y, para HTTPS, se negocian encima los protocolos de seguridad y aplicación necesarios.

```bash
ss -tn
curl -v https://example.com/
```

### Paso 5 — reenviar entre redes

Los routers reciben el paquete por una interfaz, consultan el estado de reenvío, actualizan la información de vida por saltos y lo emiten hacia otro enlace.

```bash
traceroute example.com
```

`traceroute` proporciona evidencia indirecta, visible desde el extremo, acerca de partes del camino. No es una copia remota del estado interno de cada router.

### Paso 6 — correlacionar con evidencia de paquetes

Una captura puede mostrar los bytes visibles en el punto de captura, tiempos, direcciones, puertos, flags y estructura de protocolos.

```bash
sudo tcpdump -ni any host <destination-IP>
```

Una captura tampoco puede mostrar automáticamente memoria de aplicación que nunca fue transmitida, las tablas de todos los routers ni texto plano cifrado para el cual el observador no dispone de claves.

> **Regla práctica de razonamiento:** pregunte primero *qué pregunta intento responder*. Después elija una evidencia que tenga autoridad sobre esa pregunta.

<aside id="tip-m01" class="cn-book-note cn-tip">
  <span class="cn-book-note-label">Consejo práctico</span>
  <strong>Siga una solicitud a través de las capas</strong>
  <p>Cuando un concepto resulte abstracto, elija una solicitud concreta y pregunte repetidamente: qué máquina actúa, qué estado consulta, qué identificador importa y qué herramienta puede mostrar la evidencia. Este método de cuatro preguntas funciona durante todo el curso.</p>
</aside>

## 10. Los fallos se vuelven más manejables cuando se identifica el límite

Un único mensaje como "el sitio web no funciona" puede describir fallos completamente diferentes.

| Límite | Síntoma de ejemplo | Primera evidencia útil |
|---|---|---|
| Nombres | el hostname no resuelve | `dig` |
| Enrutamiento local | no existe ruta al destino | `ip route get` |
| Enlace local / vecino | no se alcanza la puerta de enlace | `ip neigh`, captura |
| Transporte | puerto cerrado, filtrado o handshake fallido | `ss`, `nc`, captura |
| Seguridad | falla el certificado o la negociación TLS | `curl -v`, diagnósticos TLS |
| Aplicación | el servidor devuelve un error | respuesta HTTP/de aplicación |

La tabla está ordenada intencionalmente desde las dependencias cercanas al host hacia la semántica de aplicación. M13 convertirá esta idea en un método sistemático de diagnóstico.
## Síntesis resuelta — una solicitud, tres ámbitos de direccionamiento distintos

Suponga que un cliente `10.0.0.10:53000` envía una solicitud HTTP al servidor `198.51.100.20:80` mediante su router por defecto. En el primer enlace Ethernet, una vista simplificada es:

```text
aplicación:    bytes de la solicitud HTTP
transporte:    10.0.0.10:53000 → 198.51.100.20:80
IP:            10.0.0.10 → 198.51.100.20, TTL 64
Ethernet:      MAC-cliente → MAC-izquierda-router
```

Después de que el router reenvía el paquete por otro enlace Ethernet, los bytes de aplicación, los extremos de transporte y los extremos IP siguen describiendo el mismo intercambio de extremo a extremo, mientras cambian el encapsulado local y la vida por saltos:

```text
IP:            10.0.0.10 → 198.51.100.20, TTL 63
Ethernet:      MAC-derecha-router → MAC-siguiente-salto
```

Esta transición muestra por qué “destino” no es un único campo universal. El destino de transporte identifica un servicio en un extremo, el destino IP identifica el host usado para reenvío entre redes y el destino Ethernet identifica solo al siguiente receptor del enlace local actual. El router participa en la entrega sin convertirse en el extremo de la aplicación.
## Resumen del capítulo

Internet funciona porque componentes implementados de forma independiente cooperan mediante contratos estrechos.

Mantenga estas ideas en su modelo mental:

1. **La conmutación de paquetes comparte capacidad**, lo que produce colas, retardo variable y posible pérdida.
2. **Las capas separan responsabilidades**, mientras la encapsulación transporta el estado que necesita cada una.
3. **La entrega de enlace es local; el reenvío IP atraviesa redes.** Los identificadores de enlace pueden cambiar en cada salto.
4. **Internet está administrativamente distribuida.** Routers y sistemas autónomos no pertenecen a un único operador global.
5. **IP es la cintura estrecha** que conecta muchas aplicaciones con muchas tecnologías de enlace.
6. **La corrección final suele pertenecer a los extremos**, donde existe el contexto de aplicación.
7. **La evidencia tiene alcance.** Una tabla de rutas, una caché de vecinos, una captura, una consulta DNS y una respuesta de aplicación contestan preguntas diferentes.

Antes de continuar, explique el recorrido de una solicitud web sin utilizar la frase "la red se encarga". Nombre las máquinas, el estado importante y la evidencia que inspeccionaría en cada etapa.
## Conexiones de sistemas

### [OS]

Sockets, tablas de rutas, cachés de vecinos, interfaces, estado de transporte, colas y reglas de firewall son estado del sistema operativo aunque las bibliotecas lo oculten.

### [ARCH]

NICs, DMA, interrupciones, offloads, planificación de CPU y movimiento de memoria implementan el límite entre host y red.

### [DIST]

La gestión de nombres, RPC, replicación, reintentos y descubrimiento de servicios dependen de lo que la red realmente garantiza y de lo que no garantiza.

### [SEC]

Los límites entre capas también son límites de confianza. El cifrado impide intencionalmente que algunos intermediarios interpreten la semántica de aplicación.

### [PERF]

La compartición de paquetes, longitud de la ruta, serialización, colas, pérdidas y RTT determinan cómo se comportan las abstracciones en el tiempo.
## Autocomprobación

Sin volver a leer el capítulo, responda:

1. ¿Por qué un router puede reenviar una solicitud web sin conocer su método HTTP?
2. ¿Por qué el destino Ethernet del primer salto suele ser la puerta de enlace y no el servidor remoto?
3. ¿Por qué la conmutación de paquetes puede conseguir alta utilización y, al mismo tiempo, producir retardo variable?
4. ¿Qué permite la cintura estrecha de IP?
5. Mencione una función que necesite verificación final en los extremos y explique por qué.
6. ¿Qué herramientas locales utilizaría para inspeccionar DNS, rutas, vecinos, transporte y paquetes?

Después continúe con el laboratorio M01 de intercambio anotado.
