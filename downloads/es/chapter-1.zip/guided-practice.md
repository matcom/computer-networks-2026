# Práctica guiada — Seguir un mensaje a través de la pila

**Tiempo:** 8–10 minutos  
**Materiales:** papel o un editor de texto; no requiere acceso a Internet

## Predicción

Un navegador envía una solicitud HTTP a un servidor que está en otra red IP. Antes de leer el ejemplo, decida qué campos espera que permanezcan de extremo a extremo y cuáles pueden cambiar en un router:

- bytes de la aplicación;
- puertos de transporte;
- direcciones IP de origen y destino;
- direcciones MAC Ethernet de origen y destino;
- TTL/Hop Limit de IP.

Escriba `igual`, `puede cambiar` o `debe cambiar` junto a cada elemento.

## Ejemplo resuelto

Considere esta ruta simplificada:

```text
cliente H1 ── Ethernet ── router R1 ── Ethernet ── servidor H2
```

H1 crea bytes de aplicación, los entrega a transporte, coloca la unidad de transporte dentro de un paquete IP y coloca ese paquete dentro de una trama del enlace local. R1 elimina el encapsulado de enlace entrante, toma una decisión de reenvío IP, disminuye TTL/Hop Limit y crea un nuevo encapsulado de enlace para el siguiente tramo.

La separación importante es que el paquete IP ofrece la abstracción de interconexión, mientras que las direcciones Ethernet solo tienen sentido en cada enlace local. El router reenvía el paquete; no se convierte en el extremo de la conversación de aplicación.

## Microexperimento guiado

Construya una tabla de cuatro filas con las etapas `H1 envía`, `R1 recibe`, `R1 envía` y `H2 recibe`. Añada columnas para:

- carga útil de aplicación;
- puertos origen/destino de transporte;
- IP origen/destino;
- MAC origen/destino;
- TTL/Hop Limit.

Use este estado inicial:

```text
H1 IP = 10.0.0.10        H2 IP = 10.0.1.20
puerto H1 = 53000        puerto H2 = 80
MAC H1 = AA              MAC izquierda R1 = R1L
MAC derecha R1 = R1R     MAC H2 = BB
TTL inicial = 64
```

Complete la tabla. En el router mantenga iguales los extremos de transporte e IP, reduzca TTL a 63 y sustituya las direcciones de enlace para el enlace de salida.

Luego responda:

1. ¿Por qué se describe a IP como la “cintura estrecha” de Internet en esta ruta?
2. ¿Qué estado pertenece a los extremos aunque los routers participen en la entrega?

## Evidencia que debe conservar

Conserve la tabla completa y una frase que distinga **encapsulación** de **reenvío**. La frase debe dejar claro que un router puede reemplazar el encapsulado del enlace local sin terminar el intercambio de aplicación de extremo a extremo.
