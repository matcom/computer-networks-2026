Lea assignment/README.md y conserve evidencia reproducible. Este laboratorio observacional no tiene un evaluador automático. No necesita el repositorio privado.
