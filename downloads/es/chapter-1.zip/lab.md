Este módulo establece el hábito principal del curso: seguir el estado y la evidencia a través de límites en lugar de memorizar un diagrama de pila.

No existe un evaluador de programación artificial para este laboratorio. El trabajo requerido es una investigación reproducible.

## Modelo canónico

Lea `fixtures/m01-web-exchange.json` en el laboratorio descargado. El conjunto de datos proporciona una línea temporal lógica de ocho pasos, desde la resolución de nombres hasta la aplicación remota.

Para cada paso, clasifique:

- qué máquina/dispositivo actúa,
- qué capa de protocolo está implicada principalmente,
- qué estado se lee o cambia,
- qué evidencia podría hacer visible ese estado.

## Predecir

Antes de capturar algo, responda:

1. ¿Qué direcciones permanecen como extremo a extremo y cuáles cambian salto a salto?
2. ¿Un enrutador normalmente procesa el cuerpo de la solicitud remota HTTP?
3. ¿Dónde se convierte el nombre de host de destino en una dirección IP?
4. ¿Por qué un host puede necesitar una dirección de capa de enlace para su puerta de enlace predeterminada incluso cuando el servidor final está en otro continente?

## Observe su sistema

La observación obligatoria es local y no depende de acceso a Internet pública. Inspeccione el estado del host que participaría en un intercambio:

```bash
ip address
ip route
ip neigh
ss -tn
```

Registre qué puede demostrar cada comando y qué no puede demostrar acerca del intercambio canónico.

### Extensión conectada opcional

Si dispone de conectividad a Internet y de las herramientas correspondientes, compare el modelo determinista con un intercambio público real:

```bash
dig example.com
curl -I https://example.com/
traceroute example.com
```

Utilice Wireshark/TShark o `tcpdump` si los permisos de captura lo permiten. El comportamiento de Internet pública es una extensión observacional, no un requisito de corrección: rutas, direcciones, tiempos, filtrado y disponibilidad de herramientas pueden variar. No dependa de capturas de pantalla; registre comandos y evidencia textual/PCAP cuando realice la comparación.

## Construir una línea de tiempo comentada

Construya una tabla con al menos estas columnas:

| Paso | Actor | Estado de la aplicación | Estado del transporte | Estado IP | Estado del enlace | Pruebas |
|---|---|---|---|---|---|---|

No todas las celdas deben contener estado. Una parte importante del ejercicio es identificar qué capas/dispositivos **no** necesitan comprender una determinada información.

## Explicar

Responda a la pregunta guía: ¿Qué sucede, en cada límite relevante del sistema, cuando un programa se comunica con otro programa a través de una red?

Identifique explícitamente un ejemplo del principio extremo a extremo y un ejemplo de funcionalidad que necesariamente pertenece dentro de la red.

GitHub Actions no es necesario para este módulo de observación.
