Este módulo establece el hábito principal del curso: seguir el estado y la evidencia a través de límites en lugar de memorizar un diagrama de pila.

No existe un evaluador de programación artificial para este laboratorio. El trabajo requerido es una investigación reproducible.

## Modelo canónico

Lea `fixtures/m01-web-exchange.json` en el laboratorio descargado. El conjunto de datos proporciona una línea temporal lógica de ocho pasos, desde la resolución de nombres hasta la aplicación remota.

Para cada paso, clasifique:

- qué máquina/dispositivo actúa,
- qué capa de protocolo está implicada principalmente,
- qué estado se lee o cambia,
- qué evidencia podría hacer visible ese estado.

## Predecir

Antes de capturar algo, responda:

1. ¿Qué direcciones permanecen como extremo a extremo y cuáles cambian salto a salto?
2. ¿Un enrutador normalmente procesa el cuerpo de la solicitud remota HTTP?
3. ¿Dónde se convierte el nombre de host de destino en una dirección IP?
4. ¿Por qué un host puede necesitar una dirección de capa de enlace para su puerta de enlace predeterminada incluso cuando el servidor final está en otro continente?

## Observe su sistema

La observación obligatoria es local y no depende de acceso a Internet pública. Inspeccione el estado del host que participaría en un intercambio:

```bash
ip address
ip route
ip neigh
ss -tn
```

Registre qué puede demostrar cada comando y qué no puede demostrar acerca del intercambio canónico.

### Extensión conectada opcional

Si dispone de conectividad a Internet y de las herramientas correspondientes, compare el modelo determinista con un intercambio público real:

```bash
dig example.com
curl -I https://example.com/
traceroute example.com
```

Utilice Wireshark/TShark o `tcpdump` si los permisos de captura lo permiten. El comportamiento de Internet pública es una extensión observacional, no un requisito de corrección: rutas, direcciones, tiempos, filtrado y disponibilidad de herramientas pueden variar. No dependa de capturas de pantalla; registre comandos y evidencia textual/PCAP cuando realice la comparación.

## Vista previa temprana de sockets — use la herramienta antes de estudiarla formalmente

Estudiará programación con sockets de forma rigurosa en el Capítulo 10. Por ahora, use un socket únicamente para hacer tangible el estado de los extremos. **No** intente aprender todavía framing, concurrencia, lecturas parciales ni diseño robusto de protocolos.

En una terminal, ejecute este servidor mínimo sobre loopback:

```bash
python3 - <<'PY'
import socket
with socket.socket() as server:
    server.bind(("127.0.0.1", 9090))
    server.listen(1)
    conn, peer = server.accept()
    with conn:
        data = conn.recv(1024)
        print("received:", data.decode())
        conn.sendall(b"ack:" + data)
PY
```

Mientras espera, inspeccione el extremo en escucha con:

```bash
ss -ltn | grep 9090
```

Después, en otra terminal, ejecute el cliente:

```bash
python3 - <<'PY'
import socket
with socket.create_connection(("127.0.0.1", 9090)) as client:
    client.sendall(b"hello")
    print(client.recv(1024).decode())
PY
```

Conserve solo tres observaciones:

1. ¿Qué proceso estaba escuchando y cuál inició la conexión?
2. ¿Qué dirección y puerto identificaron el extremo en escucha?
3. ¿Qué partes del intercambio permanecieron completamente dentro del host?

El objetivo no es la API de Python. El objetivo es conectar un intercambio de bytes entre programas con el estado de sockets, transporte, IP y loopback que ya está siguiendo.

## Construir una línea de tiempo comentada

Construya una tabla con al menos estas columnas:

| Paso | Actor | Estado de la aplicación | Estado del transporte | Estado IP | Estado del enlace | Pruebas |
|---|---|---|---|---|---|---|

No todas las celdas deben contener estado. Una parte importante del ejercicio es identificar qué capas/dispositivos **no** necesitan comprender una determinada información.

## Explicar

Responda a la pregunta guía: ¿Qué sucede, en cada límite relevante del sistema, cuando un programa se comunica con otro programa a través de una red?

Identifique explícitamente un ejemplo del principio extremo a extremo y un ejemplo de funcionalidad que necesariamente pertenece dentro de la red.

GitHub Actions no es necesario para este módulo de observación.
