Responde ante el laboratorio y justifica cada respuesta.

1. Un host envía un paquete IP a un control remoto rojo a través de una puerta de enlace predeterminada. ¿Qué destino de capa de enlace debería aparecer normalmente en la primera trama Ethernet: el servidor remoto o la puerta de enlace? ¿Por qué?
2. Un enrutador reenvía un paquete a un nuevo enlace Ethernet. ¿Qué información se espera que cambie: direcciones de capa de enlace, direcciones IP, ambas o ninguna bajo reenvío normal?
3. Explique un beneficio y un costo de la conmutación de paquetes en comparación con la reserva permanente de capacidad para cada flujo.
4. ¿Por qué Internet puede admitir nuevas aplicaciones y nuevas tecnologías de enlace sin que sea necesario que todos los componentes comprendan a los demás?
5. Clasifique cada elemento principalmente como aplicación, transporte, red o estado de enlace: nombre de host, puerto TCP, prefijo IP, dirección MAC.
6. ¿Qué comando elegirías primero para inspeccionar el estado de la ruta local? ¿Estado vecino? ¿DNS? ¿Establecido TCP sockets?
7. Dé un ejemplo de una función para la cual la verificación del punto final sigue siendo necesaria incluso si las capas inferiores brindan asistencia.
8. Una captura de paquetes muestra el tráfico cifrado TCP/QUIC. ¿Por qué puede seguir siendo útil incluso cuando el texto plano de la aplicación no está disponible?

Después de responder, complete el cronograma de intercambio M01 anotado y revise las predicciones incorrectas.
