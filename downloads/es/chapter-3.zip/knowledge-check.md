Responda antes de ejecutar la práctica de laboratorio.

1. Calcule el retardo de serialización para un paquete de 1500 bytes a 10 Mbit/s.
2. Una ruta de fibra se hace el doble de larga mientras la velocidad de bits del enlace se mantiene constante. ¿Qué componente de retardo cambia directamente?
3. Un enlace tiene 25.000 bytes esperando por delante a 10 Mbit/s. Calcule el retardo de cola antes de que su paquete pueda comenzar a serializarse.
4. Calcule el producto ancho de banda-retardo en bytes para 1 Gbit/s y 80 ms RTT.
5. ¿Por qué `min(link rates)` es un límite superior para una ruta simple de estado estable pero no es una garantía de aplicación throughput?
6. Indique una carga de trabajo en la que predomina RTT y otra en la que domina la tasa masiva.
7. ¿Por qué dos pings consecutivos pueden tener RTT diferentes aunque la distancia geográfica no haya cambiado?
8. Explique por qué un enlace de 1 Gbit/s aún puede producir cientos de milisegundos de latencia cuando se forma una cola grande.
9. ¿Qué información experimental debe acompañar a un número `iperf3` throughput para que otro estudiante lo reproduzca/interprete?

Después de responder, ejecute las pruebas numéricas públicas y compare sus unidades con los resultados esperados.
