![Cuatro componentes del retardo de red: procesamiento, cola, serialización y propagación.](assets/book/ch03-performance-delay.png)

*Figura — Procesamiento, cola, serialización y propagación tienen causas diferentes y por tanto responden a cambios de ingeniería distintos. Separarlos evita usar el ancho de banda como explicación universal.*

## Por qué importa este capítulo

Llamar *rápida* a una red oculta preguntas diferentes. ¿Entrega pronto el primer byte? ¿Puede mantener una transferencia grande? ¿Sigue respondiendo mientras existe otro tráfico? ¿Su comportamiento es estable o solamente bueno en promedio?

Un enlace de alta capacidad puede tener latencia elevada. Un camino de baja latencia puede ofrecer poco throughput. Una red ociosa puede parecer excelente y volverse casi inutilizable cuando se llenan las colas.

Este capítulo introduce un conjunto pequeño de magnitudes que permite sustituir impresiones vagas por predicciones explícitas.

> **Deténgase y prediga.** Un enlace de 1 Gb/s sustituye a uno de 100 Mb/s entre dos ciudades. ¿Qué componentes del retardo mejoran necesariamente? ¿Cuáles pueden permanecer casi iguales?
## 1. Empiece por las unidades o el modelo ya estará equivocado

Muchos errores de rendimiento ocurren antes de empezar a razonar sobre redes: se mezclan bits con bytes, milisegundos con segundos o unidades decimales de red con unidades binarias de almacenamiento.

Mantenga visibles las conversiones básicas:

```text
1 byte = 8 bits
1 ms = 0.001 s
1 μs = 0.000001 s
1 Mbit/s = 1,000,000 bit/s
1 Gbit/s = 1,000,000,000 bit/s
```

Un buen hábito es normalizar a **bits, segundos y bits por segundo** antes de sustituir valores en una fórmula.
## 2. Cuatro mecanismos explican gran parte del retardo de un camino

Para un paquete en un salto, una descomposición útil es:

```text
procesamiento + cola + serialización + propagación
```

Cada término tiene una causa diferente. Separarlos permite preguntar qué cambio de ingeniería puede realmente mejorar el comportamiento.

### Retardo de procesamiento

Un host o router debe inspeccionar suficiente información para decidir qué hacer. Esto puede incluir analizar cabeceras, realizar búsquedas de reenvío, comprobar políticas, ejecutar software, mover datos, planificar trabajo e interactuar con hardware.

En un camino simple reenviado por hardware puede ser pequeño. En sistemas virtualizados, cifrados, sobrecargados o con mucho procesamiento en software puede resultar importante.

### Retardo de cola

Puede haber paquetes esperando por el mismo recurso de salida.

Si existen 12,500 bytes delante de nosotros en una salida de 1 Mb/s:

```text
12,500 × 8 / 1,000,000 = 0.1 s = 100 ms
```

La cola se diferencia de los otros términos porque depende fuertemente del **estado actual del tráfico**. Dos paquetes consecutivos pueden experimentar retardos de cola muy distintos.

### Retardo de serialización

Un transmisor con tasa finita necesita tiempo para colocar todos los bits de un paquete en el enlace:

```text
D_serialización = L_bits / R_bps
```

Para un paquete de 1500 bytes:

```text
a 1 Mb/s:   12,000 / 1,000,000     = 12 ms
a 1 Gb/s:   12,000 / 1,000,000,000 = 12 μs
```

Aumentar la tasa de bits reduce directamente este término.

### Retardo de propagación

Después de entrar en el medio, un bit todavía necesita tiempo para recorrerlo:

```text
D_prop = distancia / velocidad_de_propagación
```

Para 2,000 km a aproximadamente 200,000 km/s:

```text
2,000 / 200,000 = 0.010 s = 10 ms en un sentido
```

Una interfaz más rápida no consigue que la propagación electromagnética supere la velocidad física del medio.

> **Distinción clave:** serialización responde *¿cuánto tarda colocar los bits en el enlace?* Propagación responde *¿cuánto tarda en viajar un bit que ya está dentro del enlace?*

<aside id="history-m02" class="cn-book-note cn-history">
  <span class="cn-book-note-label">Historia</span>
  <strong>La teoría de colas es anterior a las redes de paquetes</strong>
  <p>Mucho antes de Internet, los ingenieros de telefonía necesitaban modelos matemáticos para recursos compartidos y tiempos de espera. Las redes de paquetes heredaron el mismo problema fundamental: el trabajo llega de forma impredecible, recursos finitos lo atienden y el retardo crece rápidamente cuando la utilización se acerca a la capacidad.</p>
  <a class="cn-book-note-source" href="../../../history/packet-switching-to-internet/">Leer la historia de diseño: Por qué la conmutación de paquetes sustituyó el modelo mental de la red telefónica →</a>
  <a class="cn-book-note-source" href="../../../history/shannon-and-channel-limits/">Leer la historia de diseño: Cómo Shannon cambió la pregunta de «¿podemos transmitir?» a «¿cuánta información puede transportar este canal?» →</a>
</aside>


<aside id="curiosity-m02" class="cn-book-note cn-curiosity">
  <span class="cn-book-note-label">Curiosidad</span>
  <strong>El ancho de banda no puede vencer a la velocidad de la luz</strong>
  <p>Un enlace de gran capacidad puede serializar datos rápidamente, pero no puede eliminar el retardo de propagación. Por eso las aplicaciones de larga distancia dependen tanto del ancho de banda como del RTT; aumentar uno no corrige automáticamente el otro.</p>
</aside>

## 3. El retardo extremo a extremo es una propiedad del camino

A través de varios saltos, un primer modelo es:

```text
D_total = Σ(D_procesamiento + D_cola + D_serialización + D_prop)
```

El modelo es útil porque cada término tiene interpretación, pero no es una fórmula universal para cronometrar cualquier carga de trabajo. Varios paquetes pueden avanzar en pipeline por enlaces diferentes y una aplicación puede introducir dependencias que no aparecen en el retardo de reenvío de un solo paquete.

Por eso conviene preguntar:

1. **¿Qué evento inicia y termina la medición?**
2. **¿Qué componentes pueden ocurrir en paralelo?**
## 4. RTT es tiempo de realimentación, no simplemente el doble de una distancia

El tiempo de ida y vuelta (RTT) mide cuánto tarda una acción en producir la realimentación relevante.

Puede incluir:

- propagación y colas del camino de ida,
- procesamiento en el receptor,
- propagación y colas del camino de vuelta,
- comportamiento de protocolo en ambos extremos.

El camino de vuelta no tiene que ser idéntico al de ida. Por tanto:

```text
RTT ≠ 2 × retardo unidireccional garantizado
```

La distancia física sigue imponiendo un límite inferior, pero el RTT observado contiene más que geografía.

> **Deténgase y prediga.** `ping` pasa de 15 ms a 180 ms mientras se realiza una subida grande y vuelve a 15 ms al detenerla. ¿Se alejaron físicamente los extremos?

La explicación probable es una cola persistente en algún recurso compartido del camino.
## 5. Throughput pregunta cuánto trabajo útil termina por unidad de tiempo

El throughput es una tasa medida durante un intervalo. Si un camino tiene capacidades:

```text
R1, R2, ..., Rn
```

una transferencia idealizada en régimen estable no puede superar:

```text
min(R1, R2, ..., Rn)
```

El recurso relevante más lento actúa como cuello de botella.

Pero el **goodput** de aplicación puede ser menor que el throughput bruto porque no todos los bits transmitidos son carga útil: existen cabeceras, retransmisiones, tráfico de control, sobrecarga de cifrado y otros datos.

La CPU, la ventana de recepción, el almacenamiento, el control de congestión, la contención Wi-Fi o el propio servidor también pueden impedir alcanzar la tasa nominal del enlace.
## 6. El producto ancho de banda-retardo indica cuántos datos puede mantener el camino en vuelo

Capacidad y tiempo de realimentación interactúan. El producto ancho de banda-retardo (BDP) es:

```text
BDP_bits = R_bps × RTT_segundos
```

Para 100 Mb/s y 40 ms de RTT:

```text
100,000,000 × 0.040 = 4,000,000 bits
                         = 500,000 bytes
```

Interpretación: aproximadamente 500 KB deben estar en vuelo para mantener ocupado un camino de 100 Mb/s con un bucle de realimentación de 40 ms.

Si el emisor solo puede mantener 64 KiB pendientes, no podrá sostener 100 Mb/s en este modelo simplificado aunque todos los enlaces físicos soporten esa tasa.

Por eso las ventanas de transporte y el control de congestión se convierten en mecanismos de rendimiento, no solamente en detalles de protocolo.
## 7. El costo inicial y el costo en régimen estable dominan a escalas diferentes

Considere un objeto de 1 MB sobre un cuello de botella de 100 Mb/s y RTT de 100 ms.

La serialización de la carga útil es:

```text
1,000,000 × 8 / 100,000,000 = 0.08 s
```

Supongamos que el establecimiento y las dependencias de la solicitud consumen tres RTT:

```text
3 × 0.1 = 0.3 s
```

Un total aproximado sería:

```text
0.38 s
```

Para esta transferencia corta domina el establecimiento. Duplicar el ancho de banda no reduciría a la mitad el tiempo final.

Ahora imagine una transferencia de 10 GB. El costo inicial fijo pierde importancia y pasa a dominar el throughput sostenido.

> **Lección de ingeniería:** optimice el término que domina la carga de trabajo real, no el número más grande impreso en la especificación de la interfaz.
## 8. La multiplexación estadística produce eficiencia y también colas

Reservar capacidad para el pico de cada usuario desperdiciaría recursos durante sus períodos de inactividad. Las redes de paquetes comparten capacidad estadísticamente.

Esto funciona bien cuando las ráfagas de usuarios diferentes no coinciden. Cuando coinciden, la salida compartida puede recibir paquetes temporalmente más rápido de lo que puede transmitirlos.

Si la tasa de llegada permanece por encima de la tasa de servicio:

```text
llegada > servicio
      ↓
crece la cola
      ↓
aumenta la latencia
      ↓
puede desbordarse el buffer
      ↓
pérdida / retransmisión / respuesta de congestión
```

Esta relación conecta directamente el rendimiento con el control de congestión de M09.
## 9. Ejemplo resuelto — identifique el término dominante antes de optimizar

Características del camino:

- cuello de botella: 10 Mb/s,
- RTT: 20 ms,
- objeto: 10 MB,
- dependencia inicial: 2 RTT.

Término de transmisión:

```text
10,000,000 × 8 / 10,000,000 = 8 s
```

Establecimiento:

```text
2 × 0.020 = 0.040 s
```

La predicción simple es aproximadamente 8.04 s. Domina la tasa de transmisión.

Cambie ahora el cuello de botella por 1 Gb/s:

```text
80,000,000 / 1,000,000,000 = 0.08 s
establecimiento = 0.04 s
```

El establecimiento representa ahora un tercio del total modelado. La misma aplicación ha cambiado de régimen de optimización.

El paso importante no fue la aritmética, sino decidir **qué mecanismo controla el tiempo observado**.
## 10. Medir es realizar un experimento, no generar números

Una medición útil comienza con una pregunta.

### RTT

```bash
ping -c 20 target
```

Pregunte:

- ¿ICMP representa bien el camino de la aplicación?
- ¿mínimo, mediana y máximo son muy diferentes?
- ¿la latencia cambia bajo carga?
- ¿existe pérdida?

### Throughput

Para experimentos controlados utilice un par servidor/cliente de `iperf3`.

Pregunte:

- ¿TCP o UDP?
- ¿un flujo o varios?
- ¿cuánto dura la prueba?
- ¿la CPU está saturada?
- ¿existe contención Wi-Fi?
- ¿hay otro cuello de botella compartido?

### Latencia bajo carga

Un experimento especialmente revelador es:

1. medir RTT en reposo,
2. iniciar una transferencia sostenida,
3. medir RTT de nuevo,
4. detener la transferencia,
5. comparar.

Un aumento grande de RTT bajo carga es evidencia de acumulación de cola en alguna parte del camino.

<aside id="tip-m02" class="cn-book-note cn-tip">
  <span class="cn-book-note-label">Consejo práctico</span>
  <strong>Mida la latencia bajo carga</strong>
  <p>Un ping sobre un enlace ocioso puede ocultar problemas de colas. Al diagnosticar rendimiento, compare el RTT antes y durante una prueba de throughput; la diferencia suele revelar si las colas dominan el retardo percibido.</p>
</aside>

## 11. Errores frecuentes de razonamiento

### “Más ancho de banda siempre significa menos latencia”

Reduce la serialización en el recurso mejorado. No reduce automáticamente propagación, procesamiento remoto, establecimiento de protocolos o colas en otro punto.

### “Un speed test me dice la velocidad de la red”

Un speed test observa un camino, una carga, un servidor, un instante, un protocolo y unas condiciones de tráfico concretas.

### “La latencia media es suficiente”

Sistemas interactivos y distribuidos suelen depender de variabilidad y colas de distribución, porque una sola dependencia lenta puede retrasar toda una operación.

### “El enlace de acceso es el único cuello de botella”

La aplicación, CPU, medio radioeléctrico, servidor remoto, ventana de transporte u otro segmento pueden dominar.

### “Un camino de 1 Gb/s transfiere un objeto de 1 Gb exactamente en un segundo”

Eso ignora sobrecarga, establecimiento, congestión, límites de aplicación y la diferencia entre gigabits y gigabytes.
## Resumen del capítulo

Mantenga separadas estas magnitudes:

1. **Procesamiento:** trabajo realizado por hosts y dispositivos.
2. **Cola:** depende del tráfico competidor y del estado actual.
3. **Serialización:** depende del tamaño del paquete y de la tasa del enlace.
4. **Propagación:** depende principalmente de distancia y medio.
5. **RTT:** tiempo de realimentación en ambos sentidos más procesamiento y colas.
6. **Throughput:** tasa sostenida de entrega, limitada por cuellos de botella.
7. **BDP:** relaciona capacidad con tiempo de realimentación y determina cuántos datos deben estar en vuelo.
8. **Transferencias cortas y masivas requieren optimizaciones diferentes.**

Antes de continuar, tome una afirmación como “el Wi-Fi está lento” y conviértala en una hipótesis que pueda medirse.
## Conexiones de sistemas

### [OS]

Buffers de sockets, planificación, disciplinas de cola, temporizadores y activación de procesos afectan latencia y throughput observados.

### [ARCH]

Tasas de NIC, DMA, ancho de banda de memoria, CPU, offloads e interrupciones pueden convertirse en cuellos de botella.

### [DIST]

Latencia de RPC, fan-out, reintentos, quórums y colas de distribución dependen de estas mismas magnitudes del camino.

### [SEC]

El cifrado y los handshakes de seguridad añaden procesamiento y, en algunos casos, dependencias adicionales de RTT.

### [PERF]

Este capítulo proporciona el vocabulario cuantitativo que utilizaremos en el resto del curso.
## Autocomprobación

Sin volver a leer:

1. Distinga retardo de serialización y de propagación.
2. Explique por qué RTT puede aumentar bajo carga sin que el camino sea geográficamente más largo.
3. Calcule el BDP de un camino de 200 Mb/s con RTT de 50 ms.
4. Explique por qué una solicitud corta puede beneficiarse más de reducir RTT que de duplicar el ancho de banda.
5. Dé dos razones por las que el goodput de aplicación puede ser menor que la tasa del cuello de botella.
6. Diseñe un experimento sencillo para detectar retardo de cola bajo carga.

Después complete el laboratorio de rendimiento M02 y compare las predicciones con la evidencia medida o determinista.
