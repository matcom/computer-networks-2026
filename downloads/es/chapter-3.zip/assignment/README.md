Es más fácil malinterpretar el rendimiento de la red cuando se mezclan las unidades, los supuestos de ruta y los costos de inicio. Esta práctica de laboratorio separa un modelo de cálculo determinista de mediciones reales.

## Predecir

Antes de ejecutar el código, responda en `REPORT.md`:

1. ¿Cuánto tiempo tarda un paquete de 1500 bytes en serializarse a 1 Mbit/s? ¿A 1 Gbit/s?
2. Una ruta de 100 Mbit/s tiene 40 ms RTT. ¿Cuántos bytes se requieren para llenar un RTT?
3. Si una ruta contiene enlaces de 1 Gbit/s, 100 Mbit/s y 250 Mbit/s, ¿qué enlace limita el estable estado throughput?
4. ¿Qué cantidades pueden revelar `ping` directamente y cuáles no?

## Construir

Implemente los TODO en `src/performance.py`:

- retardo de serialización,
- retardo de propagación,
- retrasado en la cola,
- producto ancho de banda-retardo,
- Tasa cuello de botella,
- un modelo de tiempo de transferencia deliberadamente simple.

Mantenga las unidades limpias. Las pruebas están diseñadas para exponer errores de bytes/bits y milisegundos/segundos.

## Prueba

Cada caso es público:

```bash
make list-tests
make test
make test-case CASE=bandwidth_delay
```

Agregue sus propios casos en `tests/student/`.

## Medida

Cuando las herramientas estén disponibles, realice un pequeño experimento:

```bash
ping -c 10 <reachable-host>
iperf3 -c <controlled-iperf-server>
```

Prefiera un par controlado/local para las mediciones throughput. No trate una ruta pública arbitraria de Internet como un calificador determinista.

Si `iperf3` no está disponible, utilice el trabajo de cálculo suministrado y registre que no se pudo realizar la medición opcional.

## Comparar modelo y evidencia

Utilice al menos dos predicciones de sus funciones y compárelas con las medidas observadas. Explique por qué el modelo y la medida difieren. Las posibles causas incluyen sobrecarga de protocolo, tráfico competitivo, colas, comportamiento de inicio, programación del host y el hecho de que `ping` RTT no es unidireccional retardo de propagación.

## Explicar

Complete `REPORT.md` con comandos reproducibles y razonamiento numérico. No se requieren capturas de pantalla.

GitHub Actions es opcional y, si se habilita en un repositorio exportado, solo repite las mismas pruebas locales transparentes.