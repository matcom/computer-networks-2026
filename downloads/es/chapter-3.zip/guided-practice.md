# Práctica guiada — Separar los términos de retardo antes de optimizar

**Tiempo:** 10–12 minutos  
**Materiales:** calculadora, papel o un editor de texto; no requiere acceso a Internet

## Predicción

Un paquete de 1500 bytes cruza un enlace de 100 Mb/s y después recorre 1000 km por fibra. Antes de calcular, prediga qué será mayor: el retardo de serialización o el de propagación. Prediga también si duplicar la velocidad del enlace cambia el retardo de propagación.

## Ejemplo resuelto

Para un paquete de 1500 bytes:

```text
tamaño = 1500 × 8 = 12 000 bits
serialización = 12 000 / 100 000 000 = 0.00012 s = 0.12 ms
```

Usando como aproximación docente `2 × 10^8 m/s` para la propagación en fibra:

```text
distancia = 1000 km = 1 000 000 m
propagación = 1 000 000 / 200 000 000 = 0.005 s = 5 ms
```

Aquí domina la propagación. Aumentar la tasa del enlace reduce la serialización, pero no hace que la señal recorra el medio más rápido.

## Microexperimento guiado

Use el mismo paquete de 1500 bytes y calcule estos tres casos:

| Caso | Tasa del enlace | Distancia | Paquetes ya en cola |
| --- | ---: | ---: | ---: |
| A | 100 Mb/s | 1000 km | 0 |
| B | 1 Gb/s | 1000 km | 0 |
| C | 100 Mb/s | 1000 km | 3 |

Para el caso C, aproxime el retardo de cola como tres tiempos de serialización del paquete en el enlace de 100 Mb/s. Después ordene los casos por retardo de ida.

Calcule además el producto ancho de banda-retardo de una ruta con `100 Mb/s` de capacidad y `20 ms` de RTT:

```text
BDP = tasa × RTT
```

Exprese el resultado en bits y bytes. Pregúntese qué ocurre con el rendimiento alcanzable si el emisor solo puede mantener 32 KiB en vuelo.

## Evidencia que debe conservar

Conserve las cuatro cantidades calculadas: serialización, propagación, cola del caso C y BDP. Debajo escriba una frase para cada una indicando qué cambio físico o de sistema podría modificarla. Ese será el modelo que comparará con la evidencia medida en el laboratorio.
