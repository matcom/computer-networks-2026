Keep one habit throughout the book: follow state and evidence across boundaries instead of memorizing a stack diagram.

There is no artificial programming grader for this lab. The required work is a reproducible investigation.

## Canonical model

Read `fixtures/m01-web-exchange.json` in the downloaded assignment. It provides an eight-step logical timeline from name resolution to the remote application.

For every step classify:

- which machine/device acts,
- which protocol layer is primarily involved,
- what state is read or changed,
- what evidence could make that state visible.

## Predict

Before capturing anything, answer:

1. Which addresses remain end-to-end and which change hop-by-hop?
2. Does a router normally process the remote HTTP request body?
3. Where does the destination hostname become an IP address?
4. Why may a host need a link-layer address for its default gateway even when the final server is on another continent?

## Observe your system

The required observation is local and does not depend on public-Internet access. Inspect the host state that would participate in an exchange:

```bash
ip address
ip route
ip neigh
ss -tn
```

Record what each command can establish and what it cannot establish about the canonical exchange.

### Optional connected enrichment

If Internet connectivity and the corresponding tools are available, compare the deterministic model with a live public exchange:

```bash
dig example.com
curl -I https://example.com/
traceroute example.com
```

Use Wireshark/TShark or `tcpdump` if capture permissions allow. Public-Internet behavior is observational enrichment, not a correctness requirement: paths, addresses, timing, filtering, and tool availability may vary. Do not rely on a screenshot; record commands and textual/PCAP evidence when you perform the comparison.

## Early socket preview — use the tool before studying it formally

You will study socket programming rigorously in Chapter 10. For now, use a socket only as a way to make endpoint state tangible. Do **not** try to learn framing, concurrency, partial reads, or robust protocol design yet.

In one terminal, run this tiny loopback server:

```bash
python3 - <<'PY'
import socket
with socket.socket() as server:
    server.bind(("127.0.0.1", 9090))
    server.listen(1)
    conn, peer = server.accept()
    with conn:
        data = conn.recv(1024)
        print("received:", data.decode())
        conn.sendall(b"ack:" + data)
PY
```

While it is waiting, inspect the listening endpoint with:

```bash
ss -ltn | grep 9090
```

Then, in another terminal, run the client:

```bash
python3 - <<'PY'
import socket
with socket.create_connection(("127.0.0.1", 9090)) as client:
    client.sendall(b"hello")
    print(client.recv(1024).decode())
PY
```

Keep only three observations:

1. Which process was the listener and which process initiated the connection?
2. Which address and port identified the listening endpoint?
3. Which parts of this exchange stayed entirely inside the host?

The point is not the Python API. The point is to connect a program-to-program byte exchange with the socket, transport, IP, and loopback state you are already tracing.

## Build an annotated timeline

Construct a table with at least these columns:

| Step | Actor | Application state | Transport state | IP state | Link state | Evidence |
|---|---|---|---|---|---|---|

Not every cell must contain state. An important part of the exercise is identifying which layers/devices **do not** need to understand a given piece of information.

## Explain

Answer the guiding question: what happens, at every relevant system boundary, when one program communicates with another program across a network?

Explicitly identify one example of the end-to-end principle and one example of functionality that necessarily belongs inside the network.

GitHub Actions is not needed for this observational module.
