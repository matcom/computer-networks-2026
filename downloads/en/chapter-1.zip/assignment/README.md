This module establishes the course's main habit: follow state and evidence across boundaries instead of memorizing a stack diagram.

There is no artificial programming grader for this lab. The required work is a reproducible investigation.

## Canonical model

Read `fixtures/m01-web-exchange.json` in the downloaded assignment. It provides an eight-step logical timeline from name resolution to the remote application.

For every step classify:

- which machine/device acts,
- which protocol layer is primarily involved,
- what state is read or changed,
- what evidence could make that state visible.

## Predict

Before capturing anything, answer:

1. Which addresses remain end-to-end and which change hop-by-hop?
2. Does a router normally process the remote HTTP request body?
3. Where does the destination hostname become an IP address?
4. Why may a host need a link-layer address for its default gateway even when the final server is on another continent?

## Observe your system

The required observation is local and does not depend on public-Internet access. Inspect the host state that would participate in an exchange:

```bash
ip address
ip route
ip neigh
ss -tn
```

Record what each command can establish and what it cannot establish about the canonical exchange.

### Optional connected enrichment

If Internet connectivity and the corresponding tools are available, compare the deterministic model with a live public exchange:

```bash
dig example.com
curl -I https://example.com/
traceroute example.com
```

Use Wireshark/TShark or `tcpdump` if capture permissions allow. Public-Internet behavior is observational enrichment, not a correctness requirement: paths, addresses, timing, filtering, and tool availability may vary. Do not rely on a screenshot; record commands and textual/PCAP evidence when you perform the comparison.

## Build an annotated timeline

Construct a table with at least these columns:

| Step | Actor | Application state | Transport state | IP state | Link state | Evidence |
|---|---|---|---|---|---|---|

Not every cell must contain state. An important part of the exercise is identifying which layers/devices **do not** need to understand a given piece of information.

## Explain

Answer the guiding question: what happens, at every relevant system boundary, when one program communicates with another program across a network?

Explicitly identify one example of the end-to-end principle and one example of functionality that necessarily belongs inside the network.

GitHub Actions is not needed for this observational module.