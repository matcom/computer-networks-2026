**Time:** 8–10 minutes  
**Materials:** paper or a text editor; no Internet access required

## Prediction

A browser sends an HTTP request to a server on another IP network. Before reading the example, decide which fields you expect to remain end-to-end and which can change at a router:

- application bytes;
- transport ports;
- source and destination IP addresses;
- source and destination Ethernet MAC addresses;
- IP TTL/Hop Limit.

Write `same`, `may change`, or `must change` beside each item.

## Worked example

Consider this simplified path:

```text
client H1 ── Ethernet ── router R1 ── Ethernet ── server H2
```

H1 creates application bytes, gives them to the transport layer, places the transport unit inside an IP packet, and places that packet inside a local-link frame. R1 removes the incoming link-layer framing, makes an IP forwarding decision, decreases TTL/Hop Limit, and creates new link-layer framing for the next link.

The important separation is that the IP packet provides the internetworking abstraction while Ethernet addresses are meaningful only on each local link. The router forwards the packet; it does not become the endpoint of the application conversation.

## Guided micro-experiment

Make a four-row table with the stages `H1 sends`, `R1 receives`, `R1 sends`, and `H2 receives`. Add columns for:

- application payload;
- source/destination transport ports;
- source/destination IP;
- source/destination MAC;
- TTL/Hop Limit.

Use this starting state:

```text
H1 IP = 10.0.0.10        H2 IP = 10.0.1.20
H1 port = 53000          H2 port = 80
H1 MAC = AA              R1-left MAC = R1L
R1-right MAC = R1R       H2 MAC = BB
initial TTL = 64
```

Fill the table. At the router, keep the transport endpoints and IP endpoints unchanged, decrement TTL to 63, and replace the link-layer source/destination addresses for the outgoing link.

Then answer two questions:

1. Why is IP often called the Internet's “narrow waist” in this path?
2. Which state belongs at the endpoints even though routers participate in delivery?

## Evidence to keep

Keep the completed table and one sentence distinguishing **encapsulation** from **forwarding**. Your sentence should make clear that a router can replace local-link framing without terminating the end-to-end application exchange.
