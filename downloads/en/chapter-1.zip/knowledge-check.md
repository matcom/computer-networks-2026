Answer before the lab and justify each answer.

1. A host sends an IP packet to a remote network through a default gateway. Which link-layer destination should normally appear on the first Ethernet frame: the remote server or the gateway? Why?
2. A router forwards a packet onto a new Ethernet link. Which information is expected to change: link-layer addresses, IP addresses, both, or neither under ordinary forwarding?
3. Explain one benefit and one cost of packet switching compared with permanently reserving capacity for every flow.
4. Why can the Internet support both new applications and new link technologies without requiring every component to understand every other component?
5. Classify each item as primarily application, transport, network, or link state: hostname, TCP port, IP prefix, MAC address.
6. Which command would you choose first to inspect local route state? Neighbor state? DNS? Established TCP sockets?
7. Give an example of a function for which endpoint verification remains necessary even if lower layers provide assistance.
8. A packet capture shows encrypted TCP/QUIC traffic. Why can it still be useful even when application plaintext is unavailable?

After answering, complete the annotated M01 exchange timeline and revise any incorrect predictions.
