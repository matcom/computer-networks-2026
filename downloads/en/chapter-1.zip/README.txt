Read assignment/README.md and preserve reproducible evidence. This observational laboratory has no automated grader. No private repository is required.
