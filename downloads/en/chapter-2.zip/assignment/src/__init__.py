"""Physical-layer teaching helpers for M15."""
