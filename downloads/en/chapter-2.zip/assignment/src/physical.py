"""Small deterministic physical-layer models used by the M15 laboratory."""

import math


def serialization_delay_seconds(payload_bytes, bit_rate_bps):
    if payload_bytes < 0:
        raise ValueError("payload_bytes must be non-negative")
    if bit_rate_bps <= 0:
        raise ValueError("bit_rate_bps must be positive")
    return payload_bytes * 8.0 / bit_rate_bps


def propagation_delay_seconds(distance_m, propagation_speed_mps):
    if distance_m < 0:
        raise ValueError("distance_m must be non-negative")
    if propagation_speed_mps <= 0:
        raise ValueError("propagation_speed_mps must be positive")
    return distance_m / propagation_speed_mps


def symbol_rate_baud(bit_rate_bps, bits_per_symbol):
    if bit_rate_bps < 0:
        raise ValueError("bit_rate_bps must be non-negative")
    if bits_per_symbol <= 0:
        raise ValueError("bits_per_symbol must be positive")
    return bit_rate_bps / bits_per_symbol


def snr_db(signal_power, noise_power):
    if signal_power <= 0 or noise_power <= 0:
        raise ValueError("signal_power and noise_power must be positive")
    return 10.0 * math.log10(signal_power / noise_power)


def nrz_encode(bits, low=-1.0, high=1.0):
    levels = []
    for bit in bits:
        if bit not in (0, 1):
            raise ValueError("bits must contain only 0 and 1")
        levels.append(high if bit == 1 else low)
    return levels


def nrz_decode(levels, threshold=0.0):
    return [1 if level >= threshold else 0 for level in levels]


def manchester_encode(bits, low=-1.0, high=1.0):
    """Return two half-symbol levels per bit using one teaching convention.

    0 -> high, low
    1 -> low, high
    """
    encoded = []
    for bit in bits:
        if bit == 0:
            encoded.extend([high, low])
        elif bit == 1:
            encoded.extend([low, high])
        else:
            raise ValueError("bits must contain only 0 and 1")
    return encoded
