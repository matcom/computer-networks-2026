This laboratory turns the Physical Layer chapter into a deterministic model. You will not simulate a complete radio or Ethernet PHY. Instead, you will implement the small calculations and encoding/decoding steps that make the chapter's distinctions executable.

## 1. Predict before coding

Without running code, answer:

1. Does changing a link from 100 Mb/s to 1 Gb/s change propagation speed in the same cable?
2. If one symbol represents two bits, what happens to required symbol rate for the same bit rate?
3. If noise moves a received sample across the decision threshold, what kind of error appears?
4. Why can a reported PHY rate exceed useful application goodput?

## 2. Implement the deterministic model

Complete `src/physical.py`.

The public tests exercise:

- serialization delay,
- propagation delay,
- symbol-rate conversion,
- SNR in decibels,
- two-level NRZ encoding/decoding,
- Manchester-style teaching encoding,
- invalid-input handling.

Run:

```bash
python3 scripts/run_tests.py --list
python3 scripts/run_tests.py
```

When exported as a standalone assignment, use:

```bash
make list-tests
make test
```

## 3. Explain one physical path

Choose one real interface available to you. It may be Ethernet, Wi-Fi, a VM/container-facing virtual interface, or another interface whose properties you can inspect safely.

Record what the OS can actually show with tools such as:

```bash
ip link
ethtool <interface>   # when supported

iw dev                # Wi-Fi systems, when available
```

Do not invent missing evidence. If a tool or hardware feature is unavailable, say so.

For the interface, distinguish:

- software-visible interface state,
- negotiated/reported link properties,
- physical facts you can infer,
- physical waveform details you cannot directly observe with normal OS tools.

## 4. Compare serialization and propagation

Calculate both terms for:

```text
1500-byte frame
1 Gb/s bit rate
2000 km path
2 × 10^8 m/s propagation speed
```

Then repeat only the serialization term at 100 Gb/s.

Explain why bulk capacity changes dramatically while the geographic lower bound barely changes.

## 5. Decode a noisy teaching signal

Use your NRZ encoder to generate levels for:

```text
1 0 1 1 0 0 1
```

Then manually perturb one received level so it crosses the threshold. Decode again and identify exactly which bit changes.

This is deliberately simple. The goal is to make the receiver decision visible before later courses or optional study introduce realistic coding/modulation/detection.

## 6. Finish with a systems explanation

Write a short answer to the guiding question:

> How does a computer turn bits into physical signals that another machine can recover reliably?

Your explanation must use all of these terms correctly:

```text
bit
symbol
waveform/signal
medium
bit rate
symbol rate
noise
receiver decision
PHY
MAC
```

The next chapter, Network Performance, assumes these physical distinctions and turns them into end-to-end delay and throughput models.