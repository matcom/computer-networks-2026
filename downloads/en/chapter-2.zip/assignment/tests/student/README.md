Add your own transparent physical-layer model tests here. Focus on edge cases and explanations you want to preserve.
