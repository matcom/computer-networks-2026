import unittest

from src.physical import (
    manchester_encode,
    nrz_decode,
    nrz_encode,
    propagation_delay_seconds,
    serialization_delay_seconds,
    snr_db,
    symbol_rate_baud,
)


class PhysicalLayerModelTests(unittest.TestCase):
    def test_serialization_delay(self):
        self.assertAlmostEqual(serialization_delay_seconds(1500, 1_000_000_000), 12e-6)

    def test_serialization_rejects_invalid_rate(self):
        with self.assertRaises(ValueError):
            serialization_delay_seconds(1500, 0)

    def test_propagation_delay(self):
        self.assertAlmostEqual(propagation_delay_seconds(2_000_000, 200_000_000), 0.01)

    def test_symbol_rate_for_two_bits_per_symbol(self):
        self.assertEqual(symbol_rate_baud(100_000_000, 2), 50_000_000)

    def test_snr_db(self):
        self.assertAlmostEqual(snr_db(100.0, 1.0), 20.0)

    def test_nrz_round_trip(self):
        bits = [1, 0, 1, 1, 0]
        self.assertEqual(nrz_decode(nrz_encode(bits)), bits)

    def test_nrz_threshold_can_expose_error(self):
        levels = nrz_encode([1, 0, 1])
        levels[1] = 0.2
        self.assertEqual(nrz_decode(levels), [1, 1, 1])

    def test_nrz_rejects_non_bits(self):
        with self.assertRaises(ValueError):
            nrz_encode([0, 2, 1])

    def test_manchester_encoding(self):
        self.assertEqual(
            manchester_encode([0, 1]),
            [1.0, -1.0, -1.0, 1.0],
        )

    def test_manchester_has_transition_per_bit(self):
        encoded = manchester_encode([1, 1, 0, 0])
        pairs = [encoded[i : i + 2] for i in range(0, len(encoded), 2)]
        self.assertTrue(all(a != b for a, b in pairs))


if __name__ == "__main__":
    unittest.main()
