1. A 10 Gb/s link replaces a 1 Gb/s link over the same fiber path. Which term changes directly: serialization delay, propagation delay, both equally, or neither?
2. A signaling scheme has four reliably distinguishable symbol states. How many bits can one ideal symbol encode?
3. Explain why a long run with no signal transitions can make clock recovery difficult in a simple line code.
4. Distinguish **bit rate**, **symbol rate**, and **spectral bandwidth**. Include units for each.
5. A 1500-byte frame is transmitted at 100 Mb/s. Compute its serialization delay.
6. A 1000 km path has propagation speed `2 × 10^8 m/s`. Compute one-way propagation delay.
7. Why can a higher-order modulation scheme become unreliable when SNR decreases?
8. Give one important physical limitation of copper, fiber, and radio.
9. Why can a Wi-Fi PHY rate be much higher than measured application goodput?
10. Which evidence can `ethtool` or Wi-Fi interface tools expose, and what physical behavior remains below ordinary OS visibility?
