**Time:** 10–12 minutes  
**Materials:** paper, calculator, or a text editor; no Internet access required

## Prediction

Take the bit sequence:

```text
1 0 1 1 0 0 1 0
```

Use this simple teaching encoding: bit `1 → +1 V`, bit `0 → -1 V`, one sample per bit interval. Predict the ideal sample sequence. Then predict what a receiver using a `0 V` decision threshold will do if small noise changes the sample values but does not cross the threshold.

## Worked example

The ideal encoded samples are:

```text
+1  -1  +1  +1  -1  -1  +1  -1
```

Now suppose the channel produces:

```text
+0.7  -0.6  +1.2  +0.3  -1.1  -0.4  +0.8  -0.9
```

With a `0 V` threshold, positive samples decode as `1` and negative samples as `0`, so all eight bits are recovered correctly despite the noise.

If the fourth sample were pushed from `+0.3 V` to `-0.1 V`, the receiver would make a bit error. Noise matters because the receiver observes a physical signal, not abstract bits.

## Guided micro-experiment

First decode these samples with the same `0 V` threshold:

```text
+0.9  -0.2  +0.1  -0.1  -0.8  +0.6  +0.4  -0.7
```

Write the recovered eight-bit sequence and mark which samples are closest to the decision boundary.

Next compare symbol rate and bit rate. Suppose a modulation scheme has four distinguishable symbols and maps two bits to each symbol:

```text
00 → S0
01 → S1
10 → S2
11 → S3
```

Encode `10110010` into symbols. How many symbols are transmitted? If the symbol rate is `1 Mbaud`, what is the raw bit rate in this idealized mapping?

Finally compare two delay terms for a 1500-byte frame sent over a `10 Mb/s` link spanning `200 km`, using propagation speed `2 × 10^8 m/s`:

```text
serialization = frame_bits / link_rate
propagation = distance / propagation_speed
```

Calculate both and state which one changes if the link rate becomes `100 Mb/s` while distance and medium remain the same.

## Evidence to keep

Keep the noisy-sample decoding, the bit-to-symbol mapping, and the two delay calculations. Under them, write one sentence explaining the chain `bits → symbols → physical signal → noisy observation → decoded bits`. This is the physical mechanism the later Ethernet and IP chapters will treat as a link.
