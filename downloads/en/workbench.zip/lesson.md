![A Linux networking workbench with terminal, packet capture, switch, router, and local evidence tools.](assets/book/workbench-observation.webp)

*Figure — The workbench keeps observation close to the system: inspect host state, follow packets, and preserve reproducible evidence before changing the network.*

## Why this chapter matters

A networking experiment can fail because the protocol is wrong, the host is misconfigured, a required tool is missing, a route points somewhere unexpected, or you are watching the wrong interface.

Before building transport protocols, routers, BGP policy, overlays, or distributed services, build a repeatable way to answer a simpler question:

> **What does this Linux host currently believe about networking, and what evidence supports that belief?**

Use this workbench to build the evidence vocabulary for the rest of the book. Do not memorize commands as a list; connect each command to the question it can answer.

> **Pause and predict.** `curl https://example.com/` fails. Does that tell you whether the failure is DNS, routing, TCP, TLS, HTTP, or the remote service? No. `curl` is useful precisely because it crosses many dependencies—but that also makes it a poor root-cause diagnosis by itself.
## 1. Your local host is already a complete networked system

Even before creating a laboratory topology, a Linux host contains networking state such as:

```text
processes
  ↓
sockets
  ↓
interfaces + addresses
  ↓
routes + neighbor state
  ↓
queues / firewall / policy
  ↓
NIC + driver + physical/virtual link
```

It also contains resolver configuration, local caches, namespaces, and virtual interfaces.

A Web request can interact with several of these structures before a frame leaves the machine.

Keep this systems habit from the beginning:

> **Do not treat “the network” as a black box when the host already exposes inspectable state.**

<aside id="history-m00" class="cn-book-note cn-history">
  <span class="cn-book-note-label">History</span>
  <strong>Unix made the network observable</strong>
  <p>Modern networking courses inherit a tool culture shaped by Unix: small programs expose interfaces, routes, sockets, packet captures, and name resolution as separate views of the same system. The important historical idea is not any one command, but the habit of inspecting real state instead of treating the network as a black box.</p>
  <a class="cn-book-note-source" href="https://manpages.debian.org/unstable/manpages/standards.7.en.html">Source ↗</a>
</aside>

## 2. Interfaces define where the kernel can attach networking state

An interface is an OS-visible network attachment. It may represent:

- loopback,
- physical Ethernet or Wi-Fi,
- a virtual Ethernet endpoint,
- bridge,
- tunnel,
- VPN device,
- container/VM attachment.

Inspect with:

```bash
ip link
ip address
```

Ask four questions:

1. Is the interface present and operational?
2. Which addresses and prefixes belong to it?
3. Is it the interface the route actually selects?
4. Is it in the namespace you think it is?

Interface names such as `eth0` are conventions, not universal truths. Always inspect the actual machine.
## 3. Loopback is a real protocol path without a physical network

The loopback interface lets applications use the normal IP and transport stack without sending packets onto an external medium.

This makes localhost experiments valuable because they preserve:

- socket semantics,
- transport state,
- application framing,
- many kernel code paths,

while removing variables such as Wi-Fi, switches, routers, and Internet routing.

A successful localhost experiment proves less than a successful remote experiment—but often exactly the thing you need to isolate first.

<aside id="curiosity-m00" class="cn-book-note cn-curiosity">
  <span class="cn-book-note-label">Curiosity</span>
  <strong>Your computer can network with itself</strong>
  <p>The loopback interface lets the full IP and transport stack operate without a packet leaving the machine. It is one reason localhost experiments are so useful: they exercise real socket and protocol machinery while removing the physical network from the experiment.</p>
</aside>

## 4. Addresses and prefixes describe local identity and routing scope

An address such as:

```text
192.0.2.20/24
```

contains an address plus a prefix length.

In M00, you only need to recognize that the prefix length influences which destinations are considered directly connected and which require another route or gateway.

Inspect addresses with:

```bash
ip address
```

Later chapters formalize subnetting and longest-prefix matching. For now, read the state the kernel already has and use it as evidence.
## 5. Routing state answers “where would this destination go next?”

Before transmitting an IP packet, the kernel selects a route.

Useful commands:

```bash
ip route
ip route get 198.51.100.10
```

A route can identify:

- destination prefix,
- next hop,
- output interface,
- metric or policy information.

`ip route get` is especially useful because it asks the kernel for the route it would use for one concrete destination.

That is stronger evidence than visually scanning a route table and guessing.
## 6. A default route is a fallback, not the final destination

A line such as:

```text
default via 192.0.2.1 dev eth0
```

means roughly:

> “For destinations not matched by a more specific route, send toward this next hop using this interface.”

The gateway is usually the next router, not the final remote server.

M05 will explain why more-specific prefixes override the default route. For now, recognize the distinction between:

```text
final IP destination
≠
local next hop
```
## 7. Neighbor state answers “how do I reach that next hop on this local link?”

An IP route can select a next-hop IP and interface, but Ethernet-like delivery still needs a link-layer address.

Inspect local neighbor state with:

```bash
ip neigh
```

Entries may appear reachable, stale, incomplete, failed, or in other OS-specific states.

The dependency is:

```text
usable IP route
      +
usable next-hop resolution
      ↓
frame can be constructed for local delivery
```

M04 explains ARP and IPv6 Neighbor Discovery in detail.
## 8. Sockets connect application processes to transport state

Sockets are communication endpoints exposed by the operating system.

Useful views include:

```bash
ss -lntup
ss -tn
ss -un
```

A listening TCP socket proves that the local host has an endpoint waiting on an address/port under its current namespace and privilege context.

It does **not** prove that:

- a remote client can route to it,
- a firewall allows the traffic,
- TLS will succeed,
- the application will answer correctly.

Ports identify transport endpoints, not physical switch ports.
## 9. Processes, namespaces, and privileges change what you can see and modify

Some socket details, route operations, queue configuration, and packet captures require elevated privileges.

Do not normalize “run everything as root.”

Prefer:

- least privilege,
- disposable namespaces/containers for destructive experiments,
- explicit teardown,
- clear separation between observation and modification.

Later, M12 uses namespaces as first-class network objects. In M00, simply remember that two processes on one physical host can have different network views.
## 10. DNS tools answer naming questions

`dig` exposes DNS-oriented evidence:

```bash
dig example.com
```

Inspect:

- query name/type,
- answer records,
- TTL,
- response code,
- resolver/server used.

A correct DNS answer proves something about name resolution at that observation point.

It does not prove the resulting server is reachable or healthy.

Also remember that applications can use resolver libraries, local caches, proxies, or service-specific resolution paths that differ from a direct `dig` command.
## 11. Application tools are broad end-to-end probes

`curl` is extremely useful because it can expose several stages of an HTTP(S) interaction:

```bash
curl -v https://example.com/
```

Depending on the request and build, the output can include evidence about:

- name resolution,
- selected address,
- transport connection,
- TLS negotiation,
- HTTP request/response.

That breadth is both strength and limitation.

When `curl` fails, ask which earlier dependency must be isolated next rather than treating the final error message as the root cause.
## 12. Packet capture shows traffic at one chosen observation point

Common tools include:

- `tcpdump`,
- TShark,
- Wireshark.

For example:

```bash
tcpdump -ni any
```

A capture is a time-ordered record of traffic visible **at that capture point**.

It is not a dump of the complete distributed system.

A packet can exist elsewhere without appearing at your capture point, and host offloads or encapsulation can make the same logical exchange look different on different interfaces.
## 13. Capture only traffic you are authorized to inspect

Course experiments should prefer:

- your own host,
- loopback,
- namespaces/containers,
- provided PCAPs,
- controlled lab services.

Do not capture unrelated users' traffic on shared networks.

This is both an ethical rule and good experimental design: controlled traffic is easier to interpret.
## 14. Timestamps are measurements with assumptions

Packet timestamps are useful for latency analysis, but they depend on:

- capture location,
- clock source,
- timestamp resolution,
- kernel/NIC buffering,
- offloads,
- whether the event happened before or after the observation point.

A number printed with six decimal places is not automatically accurate to six decimal places.

M02 and M13 will return to measurement quality and reproducibility.
## 15. Offloads can make host-visible packets differ from wire-visible packets

Modern NICs and kernels may perform:

- checksum offload,
- segmentation offload,
- receive aggregation,
- batching,
- other acceleration.

A capture inside the host can therefore show packet sizes or checksum states that differ from the eventual physical-wire representation.

This is not necessarily a bug in Wireshark or the NIC.

It is evidence that the capture occurred at a particular architecture boundary.
## 16. Use one tool to answer one concrete question

A useful workflow is:

| Question | Evidence |
|---|---|
| Which interfaces/addresses exist? | `ip address` |
| Which route would the kernel select? | `ip route get` |
| Is the next-hop neighbor resolved? | `ip neigh` |
| Which sockets are listening/connected? | `ss` |
| What does DNS return? | `dig` |
| What does the application interaction do? | `curl -v` |
| Which packets are visible here? | packet capture |

Troubleshooting gets easier when every command has a purpose stated **before** it is run.

<aside id="tip-m00" class="cn-book-note cn-tip">
  <span class="cn-book-note-label">Practical tip</span>
  <strong>Ask one question per tool</strong>
  <p>Use `ip address` for interface identity, `ip route` for forwarding choices, `ss` for sockets, and a packet capture for bytes on the wire. Troubleshooting gets much easier when every command answers a specific question.</p>
</aside>

## 17. Keep the Git workflow local-first

Git does not require GitHub.

You can work entirely offline with:

```bash
git init
git status
git add ...
git commit ...
git log
```

A remote repository adds collaboration, backup, and optional CI, but version control remains local.

Poor or unavailable Internet access should not prevent you from doing the core laboratory work.
## 18. Assignment export gives you a standalone workspace

Download the student laboratory ZIP linked in the current chapter and extract it into a directory you own. Work inside its `assignment/` directory; no access to the private course repository is required.

The exported workspace includes the material needed for that assignment, such as:

- instructions/objectives,
- starter code,
- public tests,
- student test directory,
- test runner,
- Makefile,
- referenced fixtures/topologies,
- optional CI workflow where configured.

The exported repository should remain useful without access to the course monorepo.
## 19. Transparent tests are executable parts of the specification

The public runner supports commands such as:

```bash
make list-tests
make test
make test-case CASE=<substring>
```

Read the tests.

A transparent test is not a leak in the grading system. It is a concrete behavioral example that can be studied, extended, and reproduced.

Use the tests to understand the protocol or system contract rather than guessing hidden cases.
## 20. Student tests turn discovered edge cases into reusable knowledge

Coding assignments include:

```text
tests/official/
tests/student/
```

When you discover a new boundary condition, turn it into a test under `tests/student/`.

That changes the question from:

> “What trick might the grader use?”

into:

> “What behavior have I not yet specified or tested?”

This is much closer to real systems engineering.
## 21. Optional CI should repeat local truth, not create a second grading universe

An exported assignment may include a GitHub Actions workflow.

Its purpose is convenience and CI practice, not a hidden source of correctness.

The invariant is:

```text
local transparent tests == optional CI tests
```

If GitHub is unavailable, the assignment remains fully testable locally.
## 22. Check capabilities without requiring every tool immediately

Run:

```bash
for tool in python3 git ip ss curl dig tcpdump; do
  command -v "$tool" || true
done
```

Core course tooling needs only a small baseline such as Python and Git.

Other tools are module-specific. Install FRRouting, containerlab, Scapy, Wireshark, and other diagnostic utilities when a chapter actually needs them rather than front-loading the entire toolchain.

A missing optional tool is an environment capability to record, not automatically a failure of the networking concept being studied.
## 23. Worked investigation — explain one successful Web request from several evidence layers

Suppose:

```bash
curl https://example.com/
```

succeeds.

Collect evidence such as:

```bash
ip address
ip route
ip route get <resolved-IP>
ip neigh
ss -tn
dig example.com
curl -v https://example.com/
```

and, where authorized, a narrow packet capture.

Build a timeline:

```text
name query / cached resolution
      ↓
selected destination address
      ↓
local route + next hop
      ↓
transport connection
      ↓
TLS/security setup
      ↓
HTTP request/response
```

Then label each observation by source:

```text
application evidence
kernel state
packet evidence
```

The exercise is successful when you can explain not only **what happened**, but **which observation supports each claim**.
## 24. Common environment and reasoning failures

### Missing command

This is an environment/tooling problem until evidence shows otherwise. Use the documented alternative or deterministic fixture when provided.

### No packet-capture privilege

The application may still work. Use supplied PCAPs/datasets or a controlled namespace/container where capture is allowed.

### No GitHub connectivity

Local Git and local transparent tests remain usable by design.

### Hard-coded interface assumptions

The machine may use `enp...`, `wlp...`, virtual interfaces, or namespace-specific names. Inspect actual state.

### Virtualized host treated as “wrong networking”

VMs, containers, VPNs, and cloud hosts legitimately add interfaces, routes, NAT, and tunnels. Those are part of the system, not noise to ignore.

### One command treated as proof of the whole path

A correct `dig`, `ping`, or `ss` result has a specific authority boundary. Do not let one successful layer stand in for all others.
## Chapter summary

M00 establishes the evidence discipline used throughout the book:

1. **The host already exposes inspectable networking state.**
2. **Interfaces, addresses, routes, neighbors, sockets, DNS, application tools, and packet captures answer different questions.**
3. **A default route is a next-hop fallback, not the final remote destination.**
4. **Packet captures are local observations whose interpretation depends on capture point and offloads.**
5. **Use least privilege and controlled environments for experiments.**
6. **Git, tests, and assignment work remain local-first.**
7. **Transparent tests are executable specification, and student tests capture discovered edge cases.**
8. **A good investigation states what each command is intended to prove before running it.**

Before continuing, choose one successful network interaction on your machine and explain it using at least one piece of application evidence, one piece of kernel state, and one packet-level observation or provided fixture.
## Systems connections

### [OS]

Interfaces, routes, neighbors, sockets, processes, namespaces, permissions, and capture hooks are operating-system state.

### [ARCH]

NICs, drivers, DMA, interrupts, queues, segmentation, checksums, and offloads explain why host-visible evidence can differ from an abstract packet model.

### [DIST]

Even a simple Web request already crosses independently failing naming, transport, security, and service components.

### [SEC]

Least privilege, capture authorization, encrypted traffic, and endpoint-controlled evidence establish important observation boundaries.

### [PERF]

Later performance claims depend on correct timestamps, workload descriptions, capture placement, counters, and system context.
## Self-check

Without looking back:

1. Which command asks the kernel for route selection to one destination?
2. Distinguish `ip route` state from `ip neigh` state.
3. What does a listening socket prove, and what does it not prove?
4. Why is `curl` useful but too broad to diagnose root cause by itself?
5. Why should every packet capture record its interface/capture point?
6. What core course work remains possible with no GitHub access?
7. Where should you place your own transparent tests?
8. Give one reason a host capture may differ from physical-wire packets.
9. Why is a missing optional command an environment fact rather than automatically a protocol failure?

Then complete the M00 workbench lab and keep the resulting baseline notes for the troubleshooting work in M13.
