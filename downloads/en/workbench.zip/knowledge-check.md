Answer before running the lab.

1. Which command would you use to inspect interface addresses? Local route selection for one destination? Neighbor state? Listening sockets?
2. Explain the difference between an IP route and an ARP/NDP neighbor entry.
3. Why can a packet capture not tell you every piece of state inside the local process or a remote router?
4. What additional information does `ss` provide that a packet capture may not provide directly?
5. If `curl` fails, why is “the network is down” an insufficient diagnosis?
6. Which parts of the course workflow still work if GitHub is unavailable for the entire semester?
7. What is the difference between `tests/official/` and `tests/student/` in an exported assignment?
8. Why should you inspect `make list-tests` rather than treating tests as secret grader behavior?
9. Give one reason NIC/kernel offloads can make a host-side capture differ from the final wire representation.

After answering, record the tools available in your terminal and follow the local loopback HTTP/TCP exchange in the laboratory. A connected DNS/HTTPS comparison is optional.
