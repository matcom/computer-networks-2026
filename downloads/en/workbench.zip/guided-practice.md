**Time:** 8–10 minutes  
**Materials:** a local Linux shell; no Internet access required

## Prediction

Before running anything, write down what you expect to find on a normal host:

1. At least one interface that does not require a physical network.
2. One or more IP addresses attached to interfaces.
3. A routing decision for loopback traffic.
4. Zero or more listening TCP sockets.

For each item, name the operating-system object you think will provide the evidence: interface state, address state, routing state, or socket state.

## Worked example

Suppose a host reports an interface named `lo` with `127.0.0.1/8`, a route for `127.0.0.0/8` through `lo`, and a process listening on `127.0.0.1:8000`.

A useful explanation is not “the network is working.” It is more precise:

- the kernel has a loopback interface;
- the address belongs to that interface;
- the route keeps matching traffic inside the host;
- a process has asked the kernel to accept TCP connections on port 8000.

Each statement is supported by a different kind of state.

## Guided micro-experiment

Run these local commands and record only the lines you need:

```bash
ip -br link
ip -br addr
ip route get 127.0.0.1
ss -ltn
```

Now answer:

1. Which interface carries `127.0.0.1` on your host?
2. Does the route lookup for `127.0.0.1` require a gateway?
3. Pick one listening socket, if any exist. Is it bound to loopback, to a specific non-loopback address, or to a wildcard address?
4. Which command above can tell you that a process is listening? Which commands cannot prove that fact?

Do not worry if your interface names or socket list differ from another machine. The mechanism, not the exact output, is the target.

## Evidence to keep

Keep four short facts: one interface fact, one address fact, one route fact, and one socket fact. For each, write the command that supports it and one claim that the command **cannot** establish. Explain those boundaries before moving to the knowledge check.
