This bootcamp is deliberately observational. It introduces the local-first workflow and establishes a baseline snapshot students can return to during later troubleshooting modules.

## 1. Check the environment

In your Linux terminal:

```bash
for tool in python3 git ip ss curl dig tcpdump; do
  command -v "$tool" || true
done
```

Record which optional networking tools are present. Do not install everything preemptively; later modules declare their own requirements.

## 2. Predict before inspecting

Before running each command, write down what you expect it to reveal:

```bash
ip address
ip route
ss -lntup
```

For each, identify whether the information belongs primarily to the application, socket/OS, network, or link view. Then predict what will change in `ss` after you start a local HTTP service in the next step.

## 3. Follow one application exchange

The required path works without Internet access. In one terminal, start a loopback-only HTTP service:

```bash
python3 -m http.server 8000 --bind 127.0.0.1
```

In another terminal, inspect the listening socket and make one request:

```bash
ss -lntp
curl -I http://127.0.0.1:8000/
```

Capture the loopback exchange with Wireshark/TShark or `tcpdump` when permissions allow. If packet capture is unavailable, preserve the `ss` output and the HTTP response headers as the required evidence.

When Internet connectivity and a configured resolver are available, add this optional comparison:

```bash
dig example.com
curl -I https://example.com/
```

Compare the live DNS/HTTPS evidence with the local exchange, but do not treat connectivity to `example.com` as a correctness requirement.

Your required evidence should identify at least:

- one local interface and its IP address,
- the loopback interface,
- the default route if one is configured,
- one listening TCP socket,
- one local HTTP/TCP exchange,
- local and peer transport ports.

If you performed the optional connected comparison, also identify one DNS query/response and the remote transport endpoint.

## 4. Git and local testing

Keep your commands and observations in a local text file. Initialize a Git repository in your own evidence directory and inspect the working tree:

```bash
git init
git status
```

Later programming labs include a standalone test runner and visible tests in their downloads. This observation-based lab does not require the private course codebase or a GitHub Actions workflow.

## 5. Explain

Create a short technical note containing commands and text evidence rather than screenshots. Answer:

1. Which information came from the kernel rather than the packet capture?
2. Which values changed between DNS and web traffic?
3. What could you still learn if GitHub were unavailable for the entire semester?
4. Which tool would you reach for first if a hostname resolved but a TCP connection failed?

There is no pass/fail programming suite for this lab: the learning objective is correct observation and interpretation. Later assignments use the transparent local test framework.