![Four hosts connected to a learning Ethernet switch with a compact MAC-to-port table.](assets/book/ch04-ethernet-switching.webp)

*Figure — A learning switch observes source addresses, records MAC-to-port state, and uses that state to forward known destinations while flooding only when necessary.*

## Why this chapter matters

IP can decide that a packet should leave through a particular interface and next hop, but that decision still has to become **local delivery on a real link**.

On an Ethernet-style LAN, two different kinds of state cooperate:

- the **host** maintains neighbor information such as IP-to-link-address mappings,
- the **switch** maintains forwarding information such as MAC-to-port mappings.

Confusing those tables is one of the fastest ways to become lost while debugging a LAN.

> **Pause and predict.** Your laptop wants to send an IP packet to a server on another continent. Which MAC address does the first Ethernet frame normally use as its destination: the remote server's, the local gateway's, or both?
## 1. Ethernet delivery is local to a link-layer domain

An Ethernet frame carries a source MAC address, a destination MAC address, and a payload such as an IPv4 or IPv6 packet.

The frame is meaningful on the current Ethernet domain. When a router forwards the enclosed IP packet onto another Ethernet link, it constructs a **new frame** appropriate to that next hop.

Therefore:

```text
Ethernet frame: local-hop delivery
IP packet:      network-layer destination across hops
```

This distinction is the foundation for understanding switches, ARP, neighbor caches, and routing boundaries.

<aside id="history-m04" class="cn-book-note cn-history">
  <span class="cn-book-note-label">History</span>
  <strong>Ethernet began at Xerox PARC</strong>
  <p>Bob Metcalfe developed Ethernet at Xerox PARC in 1973, adapting ideas from shared-medium packet communication to a local network. Ethernet later evolved from a shared coaxial medium into the switched full-duplex technology that dominates wired LANs today.</p>
  <a class="cn-book-note-source" href="../../../history/ethernet-from-shared-medium-to-switches/">Read the design history: Ethernet survived by changing almost everything around its familiar abstraction →</a>
  <a class="cn-book-note-source" href="https://www.internetsociety.org/internet/history-internet/brief-history-internet/">Source ↗</a>
</aside>

## 2. Unicast, broadcast, and unknown unicast are different cases

A unicast frame names one destination MAC address.

Ethernet broadcast uses:

```text
ff:ff:ff:ff:ff:ff
```

A simple switch floods broadcast frames throughout the broadcast domain, subject to real network controls.

An **unknown unicast** is different: it has one specific destination MAC, but the switch has not yet learned which port reaches that address. A basic learning switch also floods this case because it lacks better forwarding information.

So both can produce flooding, but for different reasons:

```text
broadcast       → intentionally addressed to everyone
unknown unicast → one destination, location not yet learned
```

<aside id="curiosity-m04" class="cn-book-note cn-curiosity">
  <span class="cn-book-note-label">Curiosity</span>
  <strong>Classic Ethernet collisions are mostly history</strong>
  <p>CSMA/CD is famous because early Ethernet nodes shared one collision domain. Modern switched full-duplex Ethernet normally gives each endpoint its own link, so collision detection is no longer part of ordinary operation even though the historical mechanism remains important for understanding Ethernet’s evolution.</p>
</aside>

## 3. A learning switch builds topology knowledge from source addresses

Suppose a switch has ports `p1`, `p2`, and `p3`.

For each received frame, a simple learning algorithm is:

```text
1. learn source_MAC → ingress_port
2. inspect destination MAC
3. broadcast?              flood other ports
4. destination unknown?    flood other ports
5. destination on ingress? filter
6. otherwise               forward to learned port
```

Why learn from the **source**?

Because receiving a frame on `p2` is direct evidence that the source address is reachable through `p2`. The destination address says where the sender *wanted* the frame to go, not where that destination actually resides.

> **Pause and predict.** An empty switch receives `A → B` on `p1`. What does it learn immediately? What can it infer about B?

It can learn `A → p1`. It cannot yet infer B's port, so it floods the frame.

<aside id="tip-m04" class="cn-book-note cn-tip">
  <span class="cn-book-note-label">Practical tip</span>
  <strong>Predict the switch table first</strong>
  <p>Before running a LAN experiment, write down which source MAC address should be learned on each port. Then predict whether the next destination is forwarded to one port, flooded, or filtered.</p>
</aside>

## 4. Worked example — the table gets smarter after each frame

Start with an empty table.

### Frame 1: `A → B` enters on `p1`

Learn:

```text
A → p1
```

B is unknown, so the frame is sent out `p2` and `p3`.

### Frame 2: `B → A` enters on `p2`

Learn:

```text
A → p1
B → p2
```

A is already known, so only `p1` receives the frame.

### Frame 3: `C → A` enters on `p3`

Learn:

```text
A → p1
B → p2
C → p3
```

A is known, so the frame goes only to `p1`.

The switch has built useful forwarding state **without a host-registration protocol**. Ordinary traffic taught it enough topology to reduce flooding.
## 5. Learned state must change when the network changes

Suppose A disconnects from `p1` and later sends from `p3`.

The next source-learning event should update:

```text
A → p3
```

Real switches also age stale entries because hosts move, links change, and old observations eventually become unreliable.

The lab omits wall-clock aging so its forwarding behavior remains deterministic. In a real switch, remember that **cached forwarding state has a lifetime and can become stale**.
## 6. ARP solves a different problem from switch learning

A host has chosen an IPv4 next-hop address, but Ethernet transmission needs a destination MAC address.

If the mapping is not cached, ARP can ask the local link:

```text
Ethernet destination: ff:ff:ff:ff:ff:ff
ARP: Who has 192.0.2.10? Tell 192.0.2.20
```

The owner can reply, allowing the requester to learn:

```text
192.0.2.10 → 02:00:00:00:00:10
```

Notice the two independent caches:

```text
host neighbor cache:   next-hop IP → MAC
switch forwarding:     MAC → port
```

The first helps a host construct a frame. The second helps a switch choose where to send that frame.
## 7. ARP fields and Ethernet fields must not be collapsed into “source” and “destination”

An ARP message is carried **inside** an Ethernet frame. During analysis, distinguish:

- Ethernet source MAC,
- Ethernet destination MAC,
- ARP sender hardware address,
- ARP sender protocol address,
- ARP target hardware address,
- ARP target protocol address.

This sounds pedantic until malformed, stale, or spoofed control traffic appears. Precise field names prevent incorrect conclusions.
## 8. The next hop is not necessarily the final IP destination

Suppose:

```text
host:    192.0.2.20/24
gateway: 192.0.2.1
server:  198.51.100.50
```

The server is outside the local `/24`, so the routing decision selects the gateway as next hop.

The host resolves:

```text
192.0.2.1 → gateway MAC
```

not the remote server's MAC.

The first frame therefore looks conceptually like:

```text
Ethernet destination = gateway MAC
IP destination       = 198.51.100.50
```

The Ethernet frame ends at the router. The router extracts the IP packet, makes a new forwarding decision, and places that packet into a new link-layer frame for the next link.

> **Worked reasoning rule:** first choose the IP next hop; only then ask how that next hop is reached on the local link.
## 9. Neighbor caches improve efficiency but create stale-state problems

Resolving every next hop for every packet would be wasteful, so hosts cache neighbor information.

Cached state introduces familiar systems concerns:

- expiration,
- mobility,
- conflicting observations,
- stale mappings,
- trust.

On Linux:

```bash
ip neigh
```

shows neighbor state and often its reachability status.

This is another example of a general distributed-systems pattern: caching makes the common path fast, but correctness becomes dependent on invalidation and freshness.
## 10. IPv6 uses Neighbor Discovery instead of ARP

IPv6 does not use ARP. Neighbor Discovery uses ICMPv6 and covers functions including neighbor resolution, router discovery, and reachability-related state.

The transferable concept is more important than memorizing one packet format:

```text
IP forwarding decision
        ↓
selected next hop
        ↓
local link-layer resolution / reachability
        ↓
frame transmission
```

IPv4/ARP and IPv6/NDP implement that pattern differently.
## 11. Loops turn flooding from useful fallback into a failure mode

Learning assumes that flooding eventually reaches the destination without circulating forever.

With redundant Ethernet links, a naive layer-2 topology can create loops. Broadcast and unknown-unicast frames may be duplicated and circulate repeatedly, consuming shared capacity and destabilizing the network.

Production Ethernet therefore needs a strategy such as:

- loop-avoidance/control protocols,
- deliberately loop-free topology,
- or architectures that move multipath behavior to another layer.

This is why “add another cable for redundancy” is not automatically safe at layer 2.
## 12. VLANs create separate logical link-layer domains

A physical switch can support multiple logical Ethernet domains using VLANs.

That means MAC learning is not simply one global mapping for every frame on the device. Forwarding state is normally scoped by VLAN or an equivalent context.

VLANs help isolate broadcast domains and administrative groups, but they do not remove the need to reason about routing between those domains.
## 13. Observe the mechanism on a real host

### Interface state

```bash
ip link
```

### Neighbor state

```bash
ip neigh
```

### Packet evidence

Capture an ARP exchange when permitted and ask:

1. Is the request's Ethernet destination broadcast?
2. Which host claims the target IP?
3. Is the reply broadcast or unicast?
4. Does the neighbor table change after the exchange?

Correlate **wire evidence** with **host state** instead of merely identifying packet names.
## 14. Failure boundaries become clearer once the two tables are separated

### Wrong or stale neighbor mapping

The host has a plausible IP route but constructs frames for the wrong MAC.

### Wrong or stale switch entry

The frame is correctly addressed, but the switch forwards it toward the wrong port until relearning or aging repairs the state.

### ARP/NDP resolution failure

The host knows which next-hop IP it wants but cannot establish usable local-link delivery.

### Layer-2 loop or broadcast storm

Repeated/flooded traffic consumes shared capacity and can overwhelm devices.

These symptoms can look similar from an application, but the evidence and corrective action differ.
## 15. Local control state has a trust model

Classic ARP does not provide cryptographic authentication of a mapping claim. A network therefore cannot assume that every received mapping is trustworthy merely because it is syntactically valid.

Operational networks may add segmentation, inspection, static configuration, switch controls, or higher-layer encryption depending on the threat model.

Keep the architectural distinction clear:

> **Any control mechanism that accepts remote state must have an explicit trust model.**
## Chapter summary

Keep these two state machines separate in your head:

1. **Host neighbor state maps next-hop network addresses to local link addresses.**
2. **Switch forwarding state maps observed link addresses to switch ports.**
3. **Switches learn from source addresses because ingress gives evidence about source reachability.**
4. **Broadcast and unknown unicast can both flood, but for different reasons.**
5. **A remote IP destination usually does not imply a remote MAC destination on the first hop.**
6. **Routers replace link-layer framing as packets cross links.**
7. **Cached state can become stale; redundant layer-2 paths can create loops.**
8. **Local control protocols depend on trust assumptions.**

Before continuing, explain exactly what changes and what remains logically stable when one IP packet crosses a router between two Ethernet LANs.
## Systems connections

### [OS]

The host kernel owns interface and neighbor state and decides when local resolution is required.

### [ARCH]

NICs and switches can perform filtering and forwarding in hardware, while drivers and DMA connect frames to host memory.

### [DIST]

Neighbor and forwarding caches are distributed cached state that may become stale after movement or topology change.

### [SEC]

ARP/NDP and other local control mechanisms require explicit trust assumptions and defensive network design.

### [PERF]

Learning reduces unnecessary flooding; loops and oversized broadcast domains consume shared capacity.
## Self-check

Without looking back:

1. Why does a learning switch update its table from the source MAC?
2. What does a fresh switch do with unknown unicast, and why?
3. Distinguish a host neighbor cache from a switch forwarding table.
4. Why does a host usually resolve its gateway rather than a remote Internet server's MAC?
5. Which headers/addresses are replaced when a router forwards an IP packet onto another Ethernet link?
6. Explain one way cached link-layer state can become stale.

Then run the M04 switch/ARP tests and correlate the deterministic model with local `ip neigh` or packet-capture evidence.
