Extract this archive and read assignment/README.md. Run tests from assignment/ with python3 scripts/run_tests.py (or make test). All tests are visible. No private repository is required.
