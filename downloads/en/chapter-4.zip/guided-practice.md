**Time:** 10–12 minutes  
**Materials:** paper or a text editor; no Internet access required

## Prediction

A learning switch has three ports. Host A is on port 1, B on port 2, and C on port 3. The switch table starts empty.

Predict what the switch does with the first frame `A → C`: does it drop, flood, or send to one known port? Also write which address the switch learns from that frame.

## Worked example

A learning switch learns from the **source** MAC address of each received frame. It uses the **destination** MAC address to decide where to send the frame.

For the first `A → C` frame:

```text
receive on port 1
learn A → port 1
destination C is unknown
flood to ports 2 and 3
```

If C replies `C → A`, the switch learns `C → port 3` and can send that reply only to port 1.

## Guided micro-experiment

Starting with an empty table, process this sequence manually:

```text
1. A → C arrives on port 1
2. C → A arrives on port 3
3. B → C arrives on port 2
4. A → B arrives on port 1
```

After each frame, record:

- the learned table;
- whether the frame is flooded or forwarded to one port;
- the output port or ports.

Then keep the same topology and consider this ARP request from A:

```text
Ethernet destination: ff:ff:ff:ff:ff:ff
ARP question: Who has 10.0.0.1? Tell 10.0.0.10.
```

Answer:

1. Why does the switch flood this frame even if its learning table already contains the gateway's MAC address?
2. What does A learn from an ARP reply that the switch itself does **not** learn?
3. Which table maps MAC addresses to switch ports, and which cache maps IP next hops to link-layer addresses?

## Evidence to keep

Keep your four-step switch-table trace plus a two-column comparison labeled `switch learning` and `ARP/neighbor resolution`. Use it to explain how the two mechanisms cooperate without solving the same problem.
