A switched LAN has two kinds of state students need to keep separate: a switch learns **MAC → port** mappings, while hosts learn **IP → MAC** mappings through ARP (or analogous IPv6 neighbor discovery mechanisms).

## Predict

Before running tests, answer:

1. What does a fresh switch do with an unknown unicast destination?
2. Which address does the switch learn: source, destination, or both?
3. What happens when a known destination is learned on the same port where a frame arrives?
4. Why is an ARP request normally sent to the Ethernet broadcast destination?
5. Which machine owns an ARP cache: switch or host?

## Build

Implement `src/lan.py`:

- source-MAC learning,
- known-unicast forwarding,
- unknown-unicast and broadcast flooding,
- same-port filtering,
- a minimal host ARP cache.

This lab's canonical topology is `switched-lan`. After extracting the student ZIP, inspect its fixture with:

```bash
python3 -m json.tool fixtures/switched-lan.json
```

An exported assignment receives the same asset as `fixtures/switched-lan.json`.

## Test

All cases are visible:

```bash
make list-tests
make test
make test-case CASE=broadcast
```

Add additional cases under `tests/student/`.

## Observe

On a real/local interface, inspect current neighbor and link state:

```bash
ip link
ip neigh
```

If packet capture is available, clear or choose an uncached neighbor interaction and observe an ARP request/reply. Identify Ethernet source/destination addresses separately from sender/target protocol addresses inside ARP.

## Explain

Describe one sequence in which the switch table changes but the host ARP cache does not, and another in which ARP state changes without changing the physical switch topology. Connect the deterministic model to packet evidence.

GitHub Actions remains optional and repeats the same public local suite only.