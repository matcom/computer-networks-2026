Answer before executing the switch/ARP lab.

1. A fresh three-port switch receives `A → B` on p1. What does it learn, and where does it transmit the frame?
2. Later it receives `B → A` on p2. Predict the forwarding decision and the complete learned table.
3. What happens if the switch has learned destination A on the same ingress port where a frame for A arrives?
4. Explain the difference between an Ethernet broadcast and an unknown unicast.
5. Why does an ARP request usually use Ethernet broadcast?
6. Your destination IP is remote and your route uses gateway `192.0.2.1`. Which IP address does your host resolve to a MAC before sending the first frame?
7. Who owns the ARP cache and who owns the MAC→port learning table?
8. A host moves from switch port p1 to p3. Which observed frame property lets the switch relearn its location?
9. Why can a valid IP route still fail to deliver traffic when neighbor resolution fails?

After answering, use `make list-tests` to map each prediction to the public cases.
