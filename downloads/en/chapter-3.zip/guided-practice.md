**Time:** 10–12 minutes  
**Materials:** calculator, paper, or a text editor; no Internet access required

## Prediction

A 1500-byte packet crosses a 100 Mb/s link and then travels 1000 km through fiber. Before calculating, predict which is larger: serialization delay or propagation delay. Also predict whether doubling the link rate changes propagation delay.

## Worked example

For a 1500-byte packet:

```text
packet size = 1500 × 8 = 12,000 bits
serialization = 12,000 / 100,000,000 = 0.00012 s = 0.12 ms
```

Using a teaching approximation of `2 × 10^8 m/s` for propagation in fiber:

```text
distance = 1000 km = 1,000,000 m
propagation = 1,000,000 / 200,000,000 = 0.005 s = 5 ms
```

Here propagation dominates serialization. Increasing the link rate reduces serialization but does not make the signal travel through the medium faster.

## Guided micro-experiment

Use the same 1500-byte packet and calculate these three cases:

| Case | Link rate | Distance | Packets already queued |
| --- | ---: | ---: | ---: |
| A | 100 Mb/s | 1000 km | 0 |
| B | 1 Gb/s | 1000 km | 0 |
| C | 100 Mb/s | 1000 km | 3 |

For case C, approximate queueing delay as three packet serialization times on the 100 Mb/s link. Then rank the cases by one-way delay.

Next calculate a bandwidth-delay product for a path with `100 Mb/s` capacity and `20 ms` RTT:

```text
BDP = rate × RTT
```

Express the answer in both bits and bytes. Ask yourself what happens to achievable throughput if the sender can keep only 32 KiB in flight on that path.

## Evidence to keep

Keep the four quantities you computed: serialization, propagation, queueing for case C, and BDP. Under them, write one sentence for each quantity stating which physical or system change could alter it. This is the model you will compare with measured evidence in the laboratory.
