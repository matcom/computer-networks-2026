import math
import unittest

from src.performance import (
    bandwidth_delay_product_bytes,
    bottleneck_rate_bps,
    propagation_delay_seconds,
    queue_delay_seconds,
    serialization_delay_seconds,
    simple_transfer_time_seconds,
)


class PerformanceCalculationTests(unittest.TestCase):
    def test_serialization_delay(self):
        self.assertAlmostEqual(serialization_delay_seconds(1500, 1_000_000), 0.012)

    def test_zero_size_serializes_immediately(self):
        self.assertEqual(serialization_delay_seconds(0, 10_000_000), 0.0)

    def test_invalid_rate_is_rejected(self):
        with self.assertRaises(ValueError):
            serialization_delay_seconds(100, 0)

    def test_propagation_delay(self):
        self.assertAlmostEqual(propagation_delay_seconds(2_000_000, 200_000_000), 0.01)

    def test_queue_delay_uses_bytes_ahead(self):
        self.assertAlmostEqual(queue_delay_seconds(12_500, 1_000_000), 0.1)

    def test_bandwidth_delay_product(self):
        self.assertAlmostEqual(bandwidth_delay_product_bytes(100_000_000, 0.04), 500_000.0)

    def test_bottleneck_rate(self):
        self.assertEqual(bottleneck_rate_bps([1_000_000_000, 100_000_000, 250_000_000]), 100_000_000)

    def test_empty_path_is_rejected(self):
        with self.assertRaises(ValueError):
            bottleneck_rate_bps([])

    def test_nonpositive_link_rate_is_rejected(self):
        with self.assertRaises(ValueError):
            bottleneck_rate_bps([100_000_000, -1])

    def test_simple_transfer_model(self):
        value = simple_transfer_time_seconds(
            payload_bytes=10_000_000,
            path_rates_bps=[1_000_000_000, 100_000_000],
            rtt_seconds=0.04,
            startup_rtts=2,
        )
        self.assertAlmostEqual(value, 0.88)

    def test_transfer_model_exposes_startup_cost(self):
        no_startup = simple_transfer_time_seconds(1_000_000, [100_000_000], 0.1, 0)
        three_rtts = simple_transfer_time_seconds(1_000_000, [100_000_000], 0.1, 3)
        self.assertAlmostEqual(three_rtts - no_startup, 0.3)

    def test_negative_payload_is_rejected(self):
        with self.assertRaises(ValueError):
            simple_transfer_time_seconds(-1, [100_000_000])


if __name__ == "__main__":
    unittest.main()
