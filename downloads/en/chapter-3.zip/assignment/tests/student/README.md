Add any additional performance cases here. Keep units explicit and test the assumptions you think are easiest to misuse.
