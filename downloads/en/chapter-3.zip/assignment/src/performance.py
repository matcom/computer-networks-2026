"""Network-performance calculations used by the M02 lab.

All public tests are visible. Keep units explicit: bytes are converted to bits
only where serialization/transmission rate requires it.
"""

from __future__ import annotations

from typing import Iterable


def _positive(name: str, value: float) -> None:
    if value <= 0:
        raise ValueError("%s must be positive" % name)


def serialization_delay_seconds(size_bytes: int, rate_bps: float) -> float:
    """Return serialization delay for *size_bytes* over *rate_bps*.

    TODO: implement size * 8 / rate while validating arguments.
    """
    raise NotImplementedError


def propagation_delay_seconds(distance_m: float, propagation_speed_m_s: float) -> float:
    """Return one-way propagation delay.

    TODO: implement distance / propagation speed while validating arguments.
    """
    raise NotImplementedError


def queue_delay_seconds(bytes_ahead: int, rate_bps: float) -> float:
    """Return the time until *bytes_ahead* have been serialized."""
    raise NotImplementedError


def bandwidth_delay_product_bytes(rate_bps: float, rtt_seconds: float) -> float:
    """Return the amount of data, in bytes, needed to fill one RTT of a path."""
    raise NotImplementedError


def bottleneck_rate_bps(link_rates_bps: Iterable[float]) -> float:
    """Return the slowest positive link rate in a path."""
    raise NotImplementedError


def simple_transfer_time_seconds(
    payload_bytes: int,
    path_rates_bps: Iterable[float],
    rtt_seconds: float = 0.0,
    startup_rtts: int = 0,
) -> float:
    """Estimate transfer time under an intentionally simple model.

    Model: startup_rtts * RTT + payload serialization at the bottleneck rate.
    This ignores loss, application think time, protocol headers, and congestion
    dynamics so students can reason about which assumption breaks first.
    """
    raise NotImplementedError
