"""Starter package for the M02 performance lab."""
