Answer before executing the lab.

1. Calculate serialization delay for a 1500-byte packet at 10 Mbit/s.
2. A fiber path is made twice as long while link bit rate stays constant. Which delay component changes directly?
3. A link has 25,000 bytes waiting ahead of you at 10 Mbit/s. Estimate the queueing delay before your packet can begin serialization.
4. Compute the bandwidth-delay product in bytes for 1 Gbit/s and 80 ms RTT.
5. Why is `min(link rates)` an upper bound for a simple steady-state path but not a guarantee of application throughput?
6. Give one workload where RTT dominates and another where bulk rate dominates.
7. Why can two consecutive pings have different RTTs even though geographic distance has not changed?
8. Explain why a 1 Gbit/s link can still produce hundreds of milliseconds of latency when a large queue forms.
9. What experimental information must accompany an `iperf3` throughput number so another person can reproduce and interpret it?

After answering, run the public numerical tests and compare your units with the expected results.
