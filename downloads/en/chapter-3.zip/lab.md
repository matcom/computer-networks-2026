Network performance is easiest to misunderstand when units, path assumptions, and startup costs are mixed together. This lab separates a deterministic calculation model from real measurements.

## Predict

Before running code, answer in `REPORT.md`:

1. How long does a 1500-byte packet take to serialize at 1 Mbit/s? At 1 Gbit/s?
2. A 100 Mbit/s path has 40 ms RTT. How many bytes are required to fill one RTT?
3. If a path contains 1 Gbit/s, 100 Mbit/s, and 250 Mbit/s links, which link limits steady-state throughput?
4. Which quantities can `ping` reveal directly, and which can it not?

## Build

Implement the TODOs in `src/performance.py`:

- serialization delay,
- propagation delay,
- queue delay,
- bandwidth-delay product,
- bottleneck rate,
- a deliberately simple transfer-time model.

Keep units explicit. The tests are designed to expose byte/bit and milliseconds/seconds mistakes.

## Test

Every case is public:

```bash
make list-tests
make test
make test-case CASE=bandwidth_delay
```

Add your own cases under `tests/student/`.

## Measure

Where the tools are available, collect a small experiment:

```bash
ping -c 10 <reachable-host>
iperf3 -c <controlled-iperf-server>
```

Prefer a controlled/local peer for throughput measurements. Do not treat an arbitrary public Internet path as a deterministic grader.

If `iperf3` is unavailable, use the supplied calculation work and record that the optional measurement could not be performed.

## Compare model and evidence

Use at least two predictions from your functions and compare them with observed measurements. Explain why the model and measurement differ. Possible causes include protocol overhead, competing traffic, queueing, startup behavior, host scheduling, and the fact that `ping` RTT is not one-way propagation delay.

## Explain

Complete `REPORT.md` with reproducible commands and numerical reasoning. Screenshots are not required.

GitHub Actions is optional and, if enabled in an exported repository, only repeats the same transparent local tests.
